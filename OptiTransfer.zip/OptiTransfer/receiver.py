"""
receiver.py
===========
Implements the receiver side of spec section 5: open the camera, help
the user aim it at the sender's screen (calibration), then loop
decoding START/DATA/END frames, writing chunks straight to disk at
their correct offset (so memory use stays flat regardless of file
size), deduping retransmissions, and finally verifying SHA-256.
"""

from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass, field

import cv2

import camera as camera_mod
import config
from display import OpticalDisplay, UserCancelled
from integrity import sha256_of_file
from packet import Packet
from protocol import PacketType


class ReceiverError(Exception):
    pass


@dataclass
class ReceiveStats:
    filename: str = ""
    filesize: int = 0
    total_packets: int = 0
    packets_received: int = 0
    duplicates: int = 0
    crc_failures: int = 0
    start_time: float = 0.0
    end_time: float = 0.0
    success: bool = False
    failure_reason: str = ""
    saved_path: str = ""

    def summary_text(self) -> str:
        elapsed = self.end_time - self.start_time
        if self.success:
            return (
                "TRANSFER SUCCESSFUL\n"
                f"File: {self.filename}\n"
                f"Saved to: {self.saved_path}\n"
                f"Size: {self.filesize / (1024*1024):.2f} MB\n"
                f"Packets received: {self.packets_received}/{self.total_packets}\n"
                f"Duplicates ignored: {self.duplicates}\n"
                f"CRC failures (NACKed): {self.crc_failures}\n"
                f"Time: {int(elapsed // 60)}m {elapsed % 60:.0f}s"
            )
        return (
            "TRANSFER FAILED\n"
            "FILE INTEGRITY CHECK FAILED\n"
            f"Reason: {self.failure_reason}\n"
            f"Packets received: {self.packets_received}/{self.total_packets}"
        )


def run_calibration(cam: camera_mod.Camera, window: str = "OptiTransfer - Calibration") -> None:
    """
    Spec section 9: "provide a calibration step where the receiver asks
    the user to point the camera at the screen and press a key."

    Shows a live feed with a marker-lock indicator until the user
    confirms with SPACE/ENTER (or cancels with Q/ESC). This does not
    decode any data -- it only checks that >=3 of the 4 ArUco corner
    markers are visible, which is the same geometric precondition the
    real decode loop needs, so a successful calibration is a reliable
    predictor that the actual transfer will be able to lock on.
    """
    from decoder import detect_markers

    cv2.namedWindow(window, cv2.WINDOW_NORMAL)
    print("\nCALIBRATION: point this laptop's camera at the SENDER's screen.")
    print("Press SPACE or ENTER once the on-screen indicator shows 'LOCKED'.")
    print("Press Q or ESC to cancel.\n")

    while True:
        frame = cam.read()
        if frame is None:
            time.sleep(config.CAMERA_CAPTURE_INTERVAL)
            continue
        found = detect_markers(frame)
        locked = len(found) >= 3
        display_frame = frame.copy()
        msg = "LOCKED - press SPACE to begin" if locked else f"searching... ({len(found)}/4 markers)"
        color = (0, 200, 0) if locked else (0, 0, 220)
        cv2.putText(display_frame, msg, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 0), 4)
        cv2.putText(display_frame, msg, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)
        cv2.imshow(window, display_frame)
        key = cv2.waitKey(30) & 0xFF
        if key in (13, 32):  # ENTER or SPACE
            break
        if key in (27, ord("q"), ord("Q")):
            cv2.destroyWindow(window)
            raise UserCancelled()

    cv2.destroyWindow(window)


class FileReceiver:
    def __init__(self, on_progress=None):
        self.on_progress = on_progress

    def receive_file(self, save_dir: str, skip_calibration: bool = False) -> ReceiveStats:
        stats = ReceiveStats()
        os.makedirs(save_dir, exist_ok=True)

        cam = camera_mod.Camera()
        cam.open()
        display = OpticalDisplay("OptiTransfer - Receiver Screen (ACK/NACK)")

        state = "WAIT_START"
        seen: set[int] = set()
        total_packets = 0
        expected_hash = ""
        filename = ""
        tmp_path = ""
        final_ack_cache: Packet | None = None
        stats.start_time = time.monotonic()

        try:
            if not skip_calibration:
                run_calibration(cam)

            while True:
                status = f"state={state} received={len(seen)}/{total_packets}"
                pkt = camera_mod.wait_for_packet(
                    cam,
                    preview_window="OptiTransfer - Receiver Camera (watching sender)",
                    expected_types={PacketType.START, PacketType.DATA, PacketType.END},
                    expected_seq=None,
                    timeout=None,
                    status_line=status,
                )
                if pkt is None:
                    continue

                # ---------------- START -----------------------------------
                if pkt.type == PacketType.START:
                    if not pkt.crc_ok:
                        self._reply(display, PacketType.NACK, pkt.seq)
                        stats.crc_failures += 1
                        continue
                    if state == "WAIT_START":
                        try:
                            meta = json.loads(pkt.payload.decode("utf-8"))
                            filename = os.path.basename(meta["filename"]) or "received_file"
                            total_packets = int(meta["total_packets"])
                            expected_hash = meta["sha256"]
                            filesize = int(meta["filesize"])
                        except (KeyError, ValueError, UnicodeDecodeError):
                            self._reply(display, PacketType.NACK, pkt.seq)
                            continue
                        stats.filename = filename
                        stats.filesize = filesize
                        stats.total_packets = total_packets
                        tmp_path = os.path.join(save_dir, filename + ".part")
                        with open(tmp_path, "wb") as f:
                            if filesize > 0:
                                f.truncate(filesize)
                        state = "RECEIVING"
                        print(f"START received: {filename} ({filesize} bytes, {total_packets} packets)")
                    self._reply(display, PacketType.ACK, pkt.seq)
                    continue

                # ---------------- DATA ------------------------------------
                if pkt.type == PacketType.DATA:
                    if state == "WAIT_START":
                        continue  # ignore stray data before metadata is known
                    if not pkt.crc_ok:
                        self._reply(display, PacketType.NACK, pkt.seq)
                        stats.crc_failures += 1
                        continue
                    if not (1 <= pkt.seq <= total_packets):
                        continue  # out-of-range, protocol desync -- ignore safely
                    if pkt.seq in seen:
                        stats.duplicates += 1
                    else:
                        offset = (pkt.seq - 1) * config.PACKET_PAYLOAD_SIZE
                        with open(tmp_path, "r+b") as f:
                            f.seek(offset)
                            f.write(pkt.payload)
                        seen.add(pkt.seq)
                        stats.packets_received = len(seen)
                        if self.on_progress:
                            self.on_progress(stats)
                    self._reply(display, PacketType.ACK, pkt.seq)
                    continue

                # ---------------- END --------------------------------------
                if pkt.type == PacketType.END:
                    if state == "WAIT_START":
                        continue
                    if not pkt.crc_ok:
                        self._reply(display, PacketType.NACK, pkt.seq)
                        stats.crc_failures += 1
                        continue
                    if final_ack_cache is None or final_ack_cache.seq != pkt.seq:
                        actual_hash = sha256_of_file(tmp_path)
                        success = actual_hash == expected_hash and len(seen) == total_packets
                        final_path = os.path.join(save_dir, filename)
                        os.replace(tmp_path, final_path)
                        stats.saved_path = final_path
                        stats.success = success
                        if not success:
                            stats.failure_reason = (
                                "SHA-256 mismatch"
                                if actual_hash != expected_hash
                                else f"missing packets ({len(seen)}/{total_packets} received)"
                            )
                        stats.end_time = time.monotonic()
                        final_ack_cache = Packet(
                            PacketType.FINAL_ACK, seq=pkt.seq, payload=bytes([1 if success else 0])
                        )
                        state = "DONE"
                    self._reply(display, final_ack_cache.type, final_ack_cache.seq, final_ack_cache.payload)
                    if state == "DONE":
                        return stats

        except UserCancelled:
            stats.failure_reason = "Cancelled by user."
            stats.end_time = time.monotonic()
            return stats
        finally:
            cam.release()
            display.close()

    @staticmethod
    def _reply(display: OpticalDisplay, ptype: PacketType, seq: int, payload: bytes = b"") -> None:
        display.show_packet(Packet(ptype, seq, payload), config.FRAME_DISPLAY_TIME)
        display.show_idle()
