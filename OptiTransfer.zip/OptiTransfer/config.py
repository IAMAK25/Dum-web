"""
config.py
=========
Single source of truth for every tunable constant in OptiTransfer.

Nothing else in the codebase should hard-code a grid size, timeout,
or pixel dimension. If you want to experiment with a denser grid,
grayscale levels, faster timeouts, etc. this is the only file you
should have to touch.

All values below were chosen empirically for a "typical" laptop
webcam (720p, ~30 fps, autofocus/autoexposure on) viewing a laptop
screen from roughly 20-40cm away. See README.md -> "Design Rationale"
for the reasoning behind each default.
"""

from dataclasses import dataclass


# ---------------------------------------------------------------------------
# Optical grid geometry
# ---------------------------------------------------------------------------
# The data-bearing area is a GRID_COLS x GRID_ROWS matrix of square cells.
# Each cell encodes exactly one bit: WHITE (255) = 1, BLACK (0) = 0.
#
# GRID_COLS * GRID_ROWS MUST be a multiple of 8 so the bitstream packs
# cleanly into whole bytes with no leftover bits to special-case.
GRID_COLS = 40
GRID_ROWS = 30
assert (GRID_COLS * GRID_ROWS) % 8 == 0, "GRID_COLS*GRID_ROWS must be a multiple of 8"

# Size, in on-screen pixels, of a single cell. Bigger cells = more tolerant
# of camera blur/distance/perspective error, but lower data density.
CELL_SIZE_PX = 16

# A thin dark gutter (in px) drawn between cells reduces bleed/blur between
# adjacent white and black cells when the camera is slightly out of focus.
CELL_GUTTER_PX = 1

# Four ArUco fiducial markers (DICT_4X4_50, ids 0-3) are placed at the
# corners of the *canvas* (outside the data grid). They are NOT part of
# the data payload -- they exist purely so the receiver can find the
# screen, correct perspective, and know exactly where the grid lives.
# This is what section 9 of the spec calls "screen/region detection".
MARKER_SIZE_PX = 90
MARKER_DICT_NAME = "DICT_4X4_50"
MARKER_IDS = (0, 1, 2, 3)  # top-left, top-right, bottom-right, bottom-left

# Empty margin (px) between the markers and the outer canvas edge, and
# between the markers and the data grid. Gives the encoder/decoder some
# breathing room and makes marker detection more reliable near screen
# edges (cameras often have optical distortion / vignetting there).
MARGIN_PX = 40

# Background color of the canvas outside the grid (mid-gray). This is
# deliberately NOT pure black or pure white so a simple Otsu threshold
# over the whole frame doesn't get skewed by a huge background block,
# and so the "idle" frame (see display.py) is visually distinct from
# both an all-black and an all-white data frame.
BACKGROUND_GRAY = 127


# ---------------------------------------------------------------------------
# Protocol / packet sizing
# ---------------------------------------------------------------------------
# Header layout (see protocol.py for the authoritative struct format):
#   MAGIC(4) + VERSION(1) + TYPE(1) + SEQ(4) + LENGTH(2) + CRC32(4) = 16 bytes
HEADER_OVERHEAD_BYTES = 16

# Total bits/bytes the grid can physically carry per optical frame.
GRID_CAPACITY_BITS = GRID_COLS * GRID_ROWS
GRID_CAPACITY_BYTES = GRID_CAPACITY_BITS // 8

# Usable payload space left over for DATA packets after the header.
PACKET_PAYLOAD_SIZE = GRID_CAPACITY_BYTES - HEADER_OVERHEAD_BYTES
assert PACKET_PAYLOAD_SIZE > 0, "Grid too small to fit even an empty packet header"


# ---------------------------------------------------------------------------
# Timing (all in seconds unless noted)
# ---------------------------------------------------------------------------
# How long the sender holds a given optical frame on screen before it is
# allowed to change. Must comfortably exceed one screen refresh interval
# AND one camera exposure/rolling-shutter interval, otherwise the camera
# risks photographing a frame that is mid-transition (see README ->
# "Problem 1: Screen/camera tearing").
FRAME_DISPLAY_TIME = 0.5

# How often the receiving side polls the camera for a new frame while
# waiting to decode. Small enough to catch a stable frame quickly,
# large enough not to peg a CPU core.
CAMERA_CAPTURE_INTERVAL = 0.04

# Number of *consecutive* camera reads that must decode to the identical
# (type, seq, payload) packet before it is accepted as real data. This is
# the core defense against tearing/motion blur/blocked view producing a
# spurious "valid-looking" decode (see README -> "Problem 1").
STABILITY_FRAMES = 3

# How long to wait for an ACK/NACK after displaying a packet before
# declaring a timeout and retrying.
ACK_TIMEOUT = 3.0

# How many times a single packet may be retransmitted before the whole
# transfer is aborted as failed.
MAX_RETRIES = 5

# While waiting for *any* valid inbound frame (e.g. receiver waiting for
# START, or sender waiting for the very first ACK) we still want an
# overall ceiling so the program never hangs forever with no camera view.
IDLE_WAIT_TIMEOUT = 30.0


# ---------------------------------------------------------------------------
# Camera
# ---------------------------------------------------------------------------
CAMERA_INDEX = 0
CAMERA_CAPTURE_WIDTH = 1280
CAMERA_CAPTURE_HEIGHT = 720

# cv2.THRESH_OTSU is used to binarize each sampled grid; this is exposed
# here in case a future grayscale/color encoder needs a different method.
ADAPTIVE_THRESHOLD_BLOCK_SIZE = 25  # must be odd
ADAPTIVE_THRESHOLD_C = 5


# ---------------------------------------------------------------------------
# File handling
# ---------------------------------------------------------------------------
RECEIVED_FILES_DIR = "received_files"
MAX_FILENAME_LEN = 255  # bytes, once utf-8 encoded, stored in START metadata


# ---------------------------------------------------------------------------
# Derived, read-only summary (handy for the UI / stats screen)
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class GridSummary:
    cols: int
    rows: int
    capacity_bytes: int
    header_overhead: int
    payload_per_packet: int
    cell_px: int
    canvas_px: tuple


def canvas_size_px() -> tuple:
    """Total canvas width/height in pixels, including markers and margins."""
    grid_w = GRID_COLS * CELL_SIZE_PX
    grid_h = GRID_ROWS * CELL_SIZE_PX
    border = MARGIN_PX * 2 + MARKER_SIZE_PX
    return (grid_w + border * 2, grid_h + border * 2)


def summary() -> GridSummary:
    return GridSummary(
        cols=GRID_COLS,
        rows=GRID_ROWS,
        capacity_bytes=GRID_CAPACITY_BYTES,
        header_overhead=HEADER_OVERHEAD_BYTES,
        payload_per_packet=PACKET_PAYLOAD_SIZE,
        cell_px=CELL_SIZE_PX,
        canvas_px=canvas_size_px(),
    )


if __name__ == "__main__":
    s = summary()
    print("OptiTransfer grid configuration")
    print(f"  Grid           : {s.cols} x {s.rows} cells ({s.cols * s.rows} bits)")
    print(f"  Frame capacity : {s.capacity_bytes} bytes")
    print(f"  Header overhead: {s.header_overhead} bytes")
    print(f"  Payload/packet : {s.payload_per_packet} bytes")
    print(f"  Cell size      : {s.cell_px}px, canvas: {s.canvas_px[0]}x{s.canvas_px[1]}px")
