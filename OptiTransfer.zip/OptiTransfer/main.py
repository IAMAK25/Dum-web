#!/usr/bin/env python3
"""
main.py
=======
OptiTransfer entry point. One script, one menu, two roles.

    ========================================
               OPTITRANSFER
    ========================================
    1. Sender
    2. Receiver
    3. Settings
    4. Exit
    Select mode:

Run with no arguments for the interactive text menu (spec section 3),
or `python main.py --gui` for the optional Tkinter front end (spec
section 20) -- see ui.py and README.md -> "Design Rationale ->
Why two entry points" for why the GUI is a thin wrapper around this
same CLI-oriented backend rather than a separate implementation.
"""

from __future__ import annotations

import sys
import traceback

import config
from camera import CameraError
from display import UserCancelled
from receiver import FileReceiver, ReceiverError
from sender import FileSender, SenderError

BANNER = r"""
========================================
           OPTITRANSFER
========================================
Offline optical file transfer (screen + camera only)
"""


def _friendly_error(exc: Exception) -> str:
    if isinstance(exc, CameraError):
        return f"Camera problem: {exc}"
    if isinstance(exc, (SenderError, ReceiverError)):
        return f"{exc}"
    if isinstance(exc, FileNotFoundError):
        return f"File not found: {exc.filename}"
    if isinstance(exc, PermissionError):
        return f"Permission denied: {exc.filename}"
    return f"Unexpected error: {exc}"


def run_sender_cli() -> None:
    path = input("Path to file to send: ").strip().strip('"')
    if not path:
        print("Cancelled: no file selected.")
        return
    print(f"\nSending '{path}'.")
    print("Position this laptop's screen so the RECEIVER's camera can see it,")
    print("and this laptop's camera so it can see the RECEIVER's screen.\n")
    sender = FileSender(on_progress=_print_sender_progress)
    try:
        stats = sender.send_file(path)
    except UserCancelled:
        print("\nCancelled by user.")
        return
    except Exception as exc:  # noqa: BLE001 - top-level friendly error boundary
        print(f"\n{_friendly_error(exc)}")
        return
    print("\n" + stats.summary_text())


def run_receiver_cli() -> None:
    save_dir = input(
        f"Folder to save received file into [default: ./{config.RECEIVED_FILES_DIR}]: "
    ).strip()
    if not save_dir:
        save_dir = config.RECEIVED_FILES_DIR
    print(f"\nReceiving into '{save_dir}'.")
    print("Position this laptop's camera so it can see the SENDER's screen,")
    print("and this laptop's screen so the SENDER's camera can see it.\n")
    receiver = FileReceiver(on_progress=_print_receiver_progress)
    try:
        stats = receiver.receive_file(save_dir)
    except UserCancelled:
        print("\nCancelled by user.")
        return
    except Exception as exc:  # noqa: BLE001
        print(f"\n{_friendly_error(exc)}")
        return
    print("\n" + stats.summary_text())


_last_print_time = [0.0]


def _print_sender_progress(stats) -> None:
    import time

    if time.monotonic() - _last_print_time[0] < 0.5 and stats.packets_sent != stats.total_packets:
        return
    _last_print_time[0] = time.monotonic()
    pct = (stats.packets_sent / stats.total_packets * 100) if stats.total_packets else 100
    print(
        f"\r  Packet {stats.packets_sent}/{stats.total_packets} "
        f"({pct:5.1f}%)  retries so far: {stats.retries}   ",
        end="",
        flush=True,
    )


def _print_receiver_progress(stats) -> None:
    import time

    if time.monotonic() - _last_print_time[0] < 0.5:
        return
    _last_print_time[0] = time.monotonic()
    pct = (stats.packets_received / stats.total_packets * 100) if stats.total_packets else 0
    print(
        f"\r  Packet {stats.packets_received}/{stats.total_packets} "
        f"({pct:5.1f}%)  duplicates: {stats.duplicates}  crc-fails: {stats.crc_failures}   ",
        end="",
        flush=True,
    )


def show_settings() -> None:
    s = config.summary()
    print("\nCurrent configuration (edit config.py to change):")
    print(f"  Grid              : {s.cols} x {s.rows} cells")
    print(f"  Frame capacity    : {s.capacity_bytes} bytes")
    print(f"  Payload / packet  : {s.payload_per_packet} bytes")
    print(f"  Cell size         : {s.cell_px}px   Canvas: {s.canvas_px[0]}x{s.canvas_px[1]}px")
    print(f"  Frame display time: {config.FRAME_DISPLAY_TIME}s")
    print(f"  ACK timeout       : {config.ACK_TIMEOUT}s")
    print(f"  Max retries       : {config.MAX_RETRIES}")
    print(f"  Camera index      : {config.CAMERA_INDEX}")
    print()


def main_menu() -> None:
    print(BANNER)
    while True:
        print("1. Sender")
        print("2. Receiver")
        print("3. Settings")
        print("4. Exit")
        choice = input("Select mode: ").strip()
        if choice == "1":
            run_sender_cli()
        elif choice == "2":
            run_receiver_cli()
        elif choice == "3":
            show_settings()
        elif choice == "4":
            print("Goodbye.")
            return
        else:
            print("Invalid choice, please enter 1, 2, 3, or 4.\n")


if __name__ == "__main__":
    if "--gui" in sys.argv:
        from ui import launch_gui

        launch_gui()
    else:
        try:
            main_menu()
        except KeyboardInterrupt:
            print("\nInterrupted. Goodbye.")
        except Exception:  # noqa: BLE001 - last-resort guard, never show a raw traceback
            print("\nA fatal, unexpected error occurred. Details below (for debugging):")
            traceback.print_exc()
            sys.exit(1)
