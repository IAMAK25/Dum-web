"""
ui.py
=====
A simple Tkinter front end (spec section 20).

Design choice -- why Tkinter is only used for the *menu/settings*, not
for the live transfer screens:
    The optical transfer itself needs a tight loop of "show an exact
    pixel-for-pixel grid" + "read the camera" + "repeat", all timed to
    the millisecond and already driven by OpenCV's own event loop
    (cv2.waitKey). Running that loop *inside* Tkinter's mainloop would
    mean either blocking Tkinter's UI thread for the whole transfer
    (freezing the window) or juggling two competing GUI event loops on
    two different windowing toolkits, which is a well-known source of
    flaky, hard-to-debug behavior. Instead, Tkinter owns the simple,
    static screens (main menu, file/folder pickers, settings, final
    result dialog) and simply calls straight into sender.py/receiver.py
    for the transfer itself, which draw their own OpenCV windows with
    live progress overlays (see camera.py's preview window). This keeps
    both halves of the UI simple instead of fighting each other.
"""

from __future__ import annotations

import threading
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext

import config
from camera import CameraError
from receiver import FileReceiver, ReceiverError
from sender import FileSender, SenderError


class OptiTransferGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("OptiTransfer")
        self.geometry("420x360")
        self.resizable(False, False)
        self._build_main_screen()

    # ------------------------------------------------------------------ #
    def _build_main_screen(self) -> None:
        for w in self.winfo_children():
            w.destroy()

        tk.Label(self, text="OPTITRANSFER", font=("Helvetica", 20, "bold")).pack(pady=(24, 4))
        tk.Label(self, text="Offline Optical Transfer", font=("Helvetica", 11)).pack(pady=(0, 24))

        tk.Button(self, text="SEND FILE", width=24, height=2, command=self._start_send).pack(pady=6)
        tk.Button(self, text="RECEIVE FILE", width=24, height=2, command=self._start_receive).pack(pady=6)
        tk.Button(self, text="SETTINGS", width=24, height=2, command=self._show_settings).pack(pady=6)
        tk.Button(self, text="EXIT", width=24, height=2, command=self.destroy).pack(pady=6)

    # ------------------------------------------------------------------ #
    def _show_settings(self) -> None:
        s = config.summary()
        text = (
            f"Grid: {s.cols} x {s.rows} cells\n"
            f"Frame capacity: {s.capacity_bytes} bytes\n"
            f"Payload/packet: {s.payload_per_packet} bytes\n"
            f"Cell size: {s.cell_px}px, canvas {s.canvas_px[0]}x{s.canvas_px[1]}px\n"
            f"Frame display time: {config.FRAME_DISPLAY_TIME}s\n"
            f"ACK timeout: {config.ACK_TIMEOUT}s\n"
            f"Max retries: {config.MAX_RETRIES}\n"
            f"Camera index: {config.CAMERA_INDEX}\n\n"
            "Edit config.py to change any of these values."
        )
        messagebox.showinfo("Settings", text)

    # ------------------------------------------------------------------ #
    def _start_send(self) -> None:
        path = filedialog.askopenfilename(title="Select a file to send")
        if not path:
            return
        self._run_transfer_screen(
            title="Sending...",
            worker=lambda log: self._do_send(path, log),
        )

    def _start_receive(self) -> None:
        save_dir = filedialog.askdirectory(title="Select a folder to save the received file")
        if not save_dir:
            save_dir = config.RECEIVED_FILES_DIR
        self._run_transfer_screen(
            title="Receiving...",
            worker=lambda log: self._do_receive(save_dir, log),
        )

    # ------------------------------------------------------------------ #
    def _run_transfer_screen(self, title: str, worker) -> None:
        """
        Replaces the main screen with a simple log panel, closes the
        Tkinter window (see module docstring for why), and runs the
        actual optical transfer in the OpenCV windows instead. The
        result is reported back via a message box once the (blocking)
        transfer finishes.
        """
        log_win = tk.Toplevel(self)
        log_win.title(title)
        log_win.geometry("480x300")
        text = scrolledtext.ScrolledText(log_win, state="disabled")
        text.pack(fill="both", expand=True)

        def log(msg: str) -> None:
            text.configure(state="normal")
            text.insert("end", msg + "\n")
            text.see("end")
            text.configure(state="disabled")

        log("Starting -- an OpenCV camera/screen window will open now.")
        log("Position the two laptops so each camera can see the other's screen.")
        log("Press Q or ESC in the OpenCV window at any time to cancel.\n")

        self.withdraw()  # hide the Tk window while OpenCV owns the screen

        def run_and_report():
            result_text = worker(log)
            self.deiconify()
            log_win.destroy()
            messagebox.showinfo("OptiTransfer result", result_text)
            self._build_main_screen()

        threading.Thread(target=run_and_report, daemon=True).start()

    # ------------------------------------------------------------------ #
    @staticmethod
    def _do_send(path: str, log) -> str:
        sender = FileSender(on_progress=lambda s: log(
            f"Packet {s.packets_sent}/{s.total_packets}  retries={s.retries}"
        ))
        try:
            stats = sender.send_file(path)
            return stats.summary_text()
        except (SenderError, CameraError) as exc:
            return f"TRANSFER FAILED\n{exc}"
        except Exception as exc:  # noqa: BLE001
            return f"TRANSFER FAILED\nUnexpected error: {exc}"

    @staticmethod
    def _do_receive(save_dir: str, log) -> str:
        receiver = FileReceiver(on_progress=lambda s: log(
            f"Packet {s.packets_received}/{s.total_packets}  dup={s.duplicates}  crc_fail={s.crc_failures}"
        ))
        try:
            stats = receiver.receive_file(save_dir)
            return stats.summary_text()
        except (ReceiverError, CameraError) as exc:
            return f"TRANSFER FAILED\n{exc}"
        except Exception as exc:  # noqa: BLE001
            return f"TRANSFER FAILED\nUnexpected error: {exc}"


def launch_gui() -> None:
    app = OptiTransferGUI()
    app.mainloop()


if __name__ == "__main__":
    launch_gui()
