"""
encoder.py
==========
Turns a Packet's raw bytes into a displayable optical frame (a numpy
BGR image) that display.py can show full-screen (or windowed) on the
sender's laptop.

Frame anatomy (see config.py for exact pixel sizes):

    +--------------------------------------------------+
    |  [M0]                                      [M1]  |  <- ArUco markers
    |         +--------------------------+              |     at the four
    |         |                          |              |     canvas corners
    |         |   GRID_COLS x GRID_ROWS  |              |     (geometric
    |         |   black/white data grid  |              |     sync, not
    |         |                          |              |     data)
    |         +--------------------------+              |
    |  [M3]                                      [M2]  |
    +--------------------------------------------------+

Design choice -- why ArUco markers instead of a home-grown corner
pattern: ArUco detection (cv2.aruco) is a mature, well-tested
implementation that is robust to moderate perspective distortion,
partial occlusion, and varying lighting, and it gives us four precisely
localized, uniquely-identified points essentially for free. Rolling a
bespoke "look for a black square in each corner" detector would be
strictly worse for the same effort, and re-implementing something
ArUco already solves would not make the *data* encoding (the actual
black/white grid) any less custom -- the grid itself, the protocol, and
the ARQ logic are all original to this project.
"""

from __future__ import annotations

import cv2
import numpy as np

import config
from packet import Packet


ARUCO_DICT = cv2.aruco.getPredefinedDictionary(
    getattr(cv2.aruco, config.MARKER_DICT_NAME)
)


# --------------------------------------------------------------------- #
# Bit <-> byte helpers (shared with decoder.py)
# --------------------------------------------------------------------- #
def bytes_to_bits(data: bytes, num_bits: int) -> np.ndarray:
    """
    Convert `data` into an array of `num_bits` 0/1 values (MSB first per
    byte), left-padded/truncated as needed to exactly fill the grid
    capacity. Extra bits beyond len(data)*8 are zero-padded; the decoder
    never looks at them because it trusts the packet's own LENGTH field.
    """
    bits = np.unpackbits(np.frombuffer(data, dtype=np.uint8))
    if len(bits) < num_bits:
        bits = np.concatenate([bits, np.zeros(num_bits - len(bits), dtype=np.uint8)])
    else:
        bits = bits[:num_bits]
    return bits


def bits_to_bytes(bits: np.ndarray) -> bytes:
    """Inverse of bytes_to_bits: pack a 0/1 bit array back into bytes."""
    n = (len(bits) // 8) * 8
    return np.packbits(bits[:n]).tobytes()


# --------------------------------------------------------------------- #
# Canvas layout helpers (kept in sync with decoder.py's expectations)
# --------------------------------------------------------------------- #
def _layout():
    """
    Returns the pixel geometry of the canvas: overall size, the four
    marker top-left anchor points, and the grid's top-left origin.
    Both encoder and decoder derive their coordinates from this single
    function so the two can never drift out of sync.
    """
    grid_w = config.GRID_COLS * config.CELL_SIZE_PX
    grid_h = config.GRID_ROWS * config.CELL_SIZE_PX
    border = config.MARGIN_PX * 2 + config.MARKER_SIZE_PX
    canvas_w = grid_w + border * 2
    canvas_h = grid_h + border * 2

    grid_x0 = border
    grid_y0 = border

    m = config.MARKER_SIZE_PX
    margin = config.MARGIN_PX
    marker_positions = {
        0: (margin, margin),  # top-left
        1: (canvas_w - margin - m, margin),  # top-right
        2: (canvas_w - margin - m, canvas_h - margin - m),  # bottom-right
        3: (margin, canvas_h - margin - m),  # bottom-left
    }
    return {
        "canvas_w": canvas_w,
        "canvas_h": canvas_h,
        "grid_x0": grid_x0,
        "grid_y0": grid_y0,
        "grid_w": grid_w,
        "grid_h": grid_h,
        "marker_positions": marker_positions,
    }


def canvas_reference_corners() -> dict:
    """
    The four *outer* corner points of each marker, in ideal (undistorted)
    canvas pixel coordinates, keyed by marker id. decoder.py uses these
    as the "destination" points for a perspective transform that maps
    the camera's distorted view back to this ideal canvas.
    """
    layout = _layout()
    m = config.MARKER_SIZE_PX
    corners = {}
    for marker_id, (x, y) in layout["marker_positions"].items():
        # ArUco corner order is TL, TR, BR, BL of the marker itself.
        corners[marker_id] = np.array(
            [[x, y], [x + m, y], [x + m, y + m], [x, y + m]], dtype=np.float32
        )
    return corners


def grid_rect() -> tuple:
    layout = _layout()
    return (layout["grid_x0"], layout["grid_y0"], layout["grid_w"], layout["grid_h"])


# --------------------------------------------------------------------- #
# Frame builders
# --------------------------------------------------------------------- #
def _blank_canvas() -> np.ndarray:
    layout = _layout()
    canvas = np.full(
        (layout["canvas_h"], layout["canvas_w"], 3),
        config.BACKGROUND_GRAY,
        dtype=np.uint8,
    )
    for marker_id, (x, y) in layout["marker_positions"].items():
        marker_img = cv2.aruco.generateImageMarker(
            ARUCO_DICT, marker_id, config.MARKER_SIZE_PX
        )
        marker_bgr = cv2.cvtColor(marker_img, cv2.COLOR_GRAY2BGR)
        canvas[y : y + config.MARKER_SIZE_PX, x : x + config.MARKER_SIZE_PX] = marker_bgr
    return canvas


def render_idle_frame() -> np.ndarray:
    """
    The "idle" frame shown between transmissions: markers visible (so the
    receiver can confirm the screen is still in view) but the data grid
    is a neutral checkerboard rather than black or white. This makes the
    idle frame visually unmistakable from any real data frame -- it will
    never accidentally pass a MAGIC+CRC32 check because it isn't even
    attempting to encode a packet.
    """
    canvas = _blank_canvas()
    gx, gy, gw, gh = grid_rect()
    checker = np.indices((config.GRID_ROWS, config.GRID_COLS)).sum(axis=0) % 2
    cell = config.CELL_SIZE_PX
    grid_img = np.kron(checker, np.ones((cell, cell))) * 255
    grid_img = grid_img.astype(np.uint8)
    grid_bgr = cv2.cvtColor(grid_img, cv2.COLOR_GRAY2BGR)
    canvas[gy : gy + gh, gx : gx + gw] = grid_bgr
    return canvas


def render_packet_frame(packet: Packet) -> np.ndarray:
    """Render `packet` as a full optical frame ready for display.show_packet()."""
    raw = packet.to_bytes()
    if len(raw) > config.GRID_CAPACITY_BYTES:
        raise ValueError(
            f"packet ({len(raw)} bytes) exceeds grid capacity "
            f"({config.GRID_CAPACITY_BYTES} bytes) -- payload too large for grid"
        )

    bits = bytes_to_bits(raw, config.GRID_CAPACITY_BITS)
    bit_grid = bits.reshape(config.GRID_ROWS, config.GRID_COLS)

    canvas = _blank_canvas()
    gx, gy, gw, gh = grid_rect()
    cell = config.CELL_SIZE_PX
    gutter = config.CELL_GUTTER_PX

    # Start each cell as black (0) then paint white where bit==1, leaving
    # a `gutter`-px dark border inside every cell to fight bleed/blur.
    grid_img = np.zeros((gh, gw), dtype=np.uint8)
    white_mask = np.kron(bit_grid, np.ones((cell, cell), dtype=np.uint8))
    grid_img[white_mask == 1] = 255
    if gutter > 0:
        # Re-darken a thin border around every cell.
        for r in range(config.GRID_ROWS):
            for c in range(config.GRID_COLS):
                y0, x0 = r * cell, c * cell
                grid_img[y0 : y0 + gutter, x0 : x0 + cell] = 0
                grid_img[y0 : y0 + cell, x0 : x0 + gutter] = 0

    grid_bgr = cv2.cvtColor(grid_img, cv2.COLOR_GRAY2BGR)
    canvas[gy : gy + gh, gx : gx + gw] = grid_bgr
    return canvas
