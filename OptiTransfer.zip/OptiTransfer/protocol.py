"""
protocol.py
===========
Defines the OptiTransfer wire format: the magic/preamble bytes, the
packet-type enum, and the binary header layout.

    +----------+---------+--------+--------+----------+----------+-----------+
    | MAGIC    | VERSION | TYPE   | SEQ    | LENGTH   | PAYLOAD  | CRC32     |
    | 4 bytes  | 1 byte  | 1 byte | 4 bytes| 2 bytes  | LENGTH   | 4 bytes   |
    +----------+---------+--------+--------+----------+----------+-----------+

Field-by-field:

MAGIC (4 bytes, b"OPTX")
    A fixed byte pattern that must be present for a decoded bit-grid to
    even be considered a candidate packet. This is the *software*
    preamble. The *optical/geometric* preamble is handled separately by
    the four ArUco corner markers (see encoder.py/decoder.py) -- those
    tell the receiver "a screen is here and this is its orientation",
    while MAGIC tells the receiver "the bits I just sampled are real
    protocol data, not visual noise from a transition frame".

VERSION (1 byte)
    Protocol version. Lets a future decoder reject/handle frames from an
    incompatible sender instead of silently mis-parsing them.

TYPE (1 byte)
    One of PacketType below: START, DATA, ACK, NACK, END, FINAL_ACK.

SEQ (4 bytes, big-endian unsigned)
    Sequence number. Meaning depends on TYPE:
      - START     : always 0
      - DATA      : 1..total_packets (the chunk index, 1-based)
      - END       : total_packets + 1
      - ACK/NACK  : echoes the SEQ of the packet being acknowledged
      - FINAL_ACK : echoes the END packet's SEQ

LENGTH (2 bytes, big-endian unsigned)
    Number of bytes in PAYLOAD (0-65535). Because the optical grid has a
    *fixed* physical capacity (GRID_CAPACITY_BYTES), every transmitted
    frame occupies the same number of cells regardless of how much real
    payload it carries. Any bytes in the grid beyond
    HEADER + LENGTH + CRC32 are padding and are ignored by the decoder.

PAYLOAD (LENGTH bytes)
    Type-dependent contents:
      - START     : UTF-8 JSON metadata (filename, size, sha256, ...)
      - DATA      : raw file chunk bytes
      - ACK/NACK  : empty
      - END       : empty
      - FINAL_ACK : 1 byte, 0x01 = integrity OK, 0x00 = integrity FAILED

CRC32 (4 bytes, big-endian unsigned)
    zlib.crc32 computed over every preceding field (MAGIC..PAYLOAD).
    This is the *packet-level* integrity check (see spec section 13).
    File-level integrity uses a full SHA-256 across the reassembled file,
    computed independently by sender and receiver and compared in the
    END / FINAL_ACK handshake.

Why a software MAGIC preamble in addition to ArUco markers?
    The ArUco markers are always visible on screen (they frame every
    optical frame, including "idle"/blank frames), so their presence
    alone does not prove the *interior* grid contains a real packet
    -- it could be a transition frame caught mid-redraw, or the idle
    pattern. Requiring MAGIC to decode correctly (plus a passing CRC32)
    is what actually certifies "this is packet data", and requiring
    that result to repeat for STABILITY_FRAMES consecutive camera reads
    (see camera.py) is what certifies "the screen has actually settled".
"""

import struct
from enum import IntEnum

MAGIC = b"OPTX"
VERSION = 1

# Struct format for the fixed-size header (everything except PAYLOAD/CRC).
# > = big-endian, no padding.
#   4s = MAGIC, B = VERSION, B = TYPE, I = SEQ, H = LENGTH
HEADER_FMT = ">4sBBIH"
HEADER_SIZE = struct.calcsize(HEADER_FMT)  # 12 bytes
CRC_FMT = ">I"
CRC_SIZE = struct.calcsize(CRC_FMT)  # 4 bytes


class PacketType(IntEnum):
    START = 0x01
    DATA = 0x02
    ACK = 0x03
    NACK = 0x04
    END = 0x05
    FINAL_ACK = 0x06

    @classmethod
    def is_valid(cls, value: int) -> bool:
        return value in cls._value2member_map_


class ProtocolError(Exception):
    """Raised when bytes cannot be parsed as a valid OptiTransfer packet."""


# Sentinel SEQ values -----------------------------------------------------
SEQ_START = 0


def seq_for_end(total_packets: int) -> int:
    return total_packets + 1
