# OptiTransfer

Offline file transfer between two laptops using **only their screens and
cameras**. No Wi-Fi, Bluetooth, Ethernet, USB, or sockets of any kind —
data physically travels as light, laptop screen → other laptop's camera,
and back again for acknowledgements.

```
Laptop A                                  Laptop B
 screen  ── (light, through the air) ──▶   camera
 camera  ◀── (light, through the air) ──   screen
```

---

## 1. Before the code: thinking through the problem

This section is the part of the spec that says *"don't blindly implement
my idea — tell me what's actually going to break."* Every problem below
was found by actually building and stress-testing the pipeline (see
`tests/test_encoder_decoder.py`), not guessed at.

### Problem 1 — Screen/camera tearing (the sync problem)
**Why it happens:** the sender's screen redraws at its refresh rate
(typically 60 Hz ≈ 16.7 ms/frame) and the camera captures at its own,
unsynchronized rate (typically 30 fps, often with a rolling shutter that
reads the sensor row-by-row over several milliseconds). Nothing
guarantees the two are ever aligned. A camera frame can be exposed while
the screen is mid-redraw, so part of the photographed image is the old
grid and part is the new one.
**Solution implemented:** two independent defenses, stacked:
1. The sender holds every frame on screen for `FRAME_DISPLAY_TIME`
   (default 0.5 s) — dozens of screen refresh cycles and camera exposures
   — before changing it, in `display.py`.
2. The receiver does not trust a single successful decode. `camera.py`'s
   `wait_for_packet()` requires the **same** decoded `(type, seq,
   payload)` to reproduce for `STABILITY_FRAMES` (default 3) *consecutive*
   camera reads before accepting it. A torn/transitional capture almost
   always either fails the MAGIC/CRC check outright or decodes to
   something that does not reproduce on the next read, so the stability
   counter simply resets and the loop tries again a frame later.
**Trade-off:** this adds latency (≈`STABILITY_FRAMES × CAMERA_CAPTURE_INTERVAL`
plus the mandatory hold time) to every single packet. That's the price of
correctness on an inherently un-synchronized channel; see Problem 3 for
what this costs in throughput.

### Problem 2 — Finding the screen and correcting perspective
**Why it happens:** the camera won't be perfectly parallel to the screen,
won't perfectly fill its field of view, and the exact position will
change between runs. Spec section 9 explicitly asks for this to be
handled, not assumed away.
**Solution implemented:** four ArUco fiducial markers (`cv2.aruco`,
`DICT_4X4_50`, ids 0–3) are rendered at the four corners of the canvas by
`encoder.py`, outside the data grid. `decoder.py` detects them, builds a
homography from their known ideal canvas positions to wherever they
actually appear in the camera frame (`cv2.findHomography` with RANSAC),
and warps the whole camera frame back into "ideal canvas" coordinates
before sampling any data cells. This works with only 3 of the 4 markers
visible, so partial occlusion doesn't stop the transfer.
**Why ArUco and not a bespoke corner-finder:** the spec's "no QR codes"
constraint is about not using QR codes *as the data-carrying format* —
the actual payload here is the original black/white grid, not a QR
symbol. ArUco markers are a separate, much simpler primitive (just four
small fiducials for geometric registration) built into OpenCV, mature and
heavily tested for exactly this "find + undistort a planar target" job.
Reinventing that specific wheel would not make the protocol, the grid
encoding, or the ARQ logic any more original — those are the actually
custom parts of this project.
**Trade-off:** the markers permanently use up four small squares of
screen real estate that carry no payload. Measured cost at default
settings: negligible (see §6 canvas layout) compared to what robust
detection buys you.

### Problem 3 — Grid density vs. reliability vs. throughput
**Why it happens:** more cells = more bits per optical frame = higher
throughput, but each cell also gets physically smaller, so it takes fewer
camera pixels, fewer stray photons, or a little more blur to misread it.
There is a real ceiling before error rates spike.
**What we measured (see `tests/test_encoder_decoder.py` and §9 below):**
at the default 40×30 grid / 16 px cells, decode succeeded in **100% of
simulated frames** under mild-to-moderate camera angles, heavy Gaussian
blur, additive sensor noise, and both under- and over-exposure. Success
dropped to **75–85% per single camera frame** only under *very* steep
viewing angles (the kind calibration is specifically designed to catch
and have the user correct). Because of the stop-and-wait ARQ (Problem 5),
even a 75% single-frame success rate still converges to a delivered
packet almost every time — it just costs an extra retry or two.
**Solution implemented:** the grid size lives in exactly one place
(`config.GRID_COLS`/`GRID_ROWS`, `config.CELL_SIZE_PX`) and nothing else
in the codebase hard-codes it, so this dial can be turned without
touching any other file.
**Trade-off:** the honest number this produces (see §8 Performance) is
slow — roughly 0.1 KB/s at the shipped defaults. That is a genuine,
inherent cost of a stop-and-wait optical link with wide reliability
margins, not a bug. §11 (Future Improvements) explains the concrete
levers (denser grid, grayscale/color levels, windowed ACKs) that trade
some of that reliability margin back for speed once the base protocol is
proven correct.

### Problem 4 — Ambient lighting / auto-exposure drift
**Why it happens:** webcams constantly auto-adjust exposure/white-balance,
and room lighting is never perfectly even, so "white" and "black" are
not fixed pixel values — they can drift over the course of a transfer and
even across one frame.
**Solution implemented:** `decoder.sample_grid()` never compares a cell
to a fixed threshold. It computes the mean intensity of every cell, then
runs Otsu's method **on that specific frame's own cell-mean
distribution**, which adapts automatically to whatever brightness range
that particular frame happened to have.
**Trade-off:** Otsu assumes a roughly bimodal distribution (i.e. the grid
actually has a healthy mix of black and white cells). A pathological
payload that happened to compress to almost-all-zeros would be a harder
case; in practice CRC32 catches any resulting misreads and the packet is
simply retransmitted.

### Problem 5 — The ACK channel is optical too, and the link is half-duplex
**Why it happens:** spec section 10 forbids sockets even for ACK — the
receiver's own screen and the sender's own camera have to carry it. That
means, physically, only one laptop can be "the one currently being
photographed" in a meaningful sense at a time.
**Solution implemented:** the protocol is a strict, symmetric
stop-and-wait exchange. The camera/decoder/display code paths are
identical on both machines (`camera.py`, `decoder.py`, `encoder.py`,
`display.py` don't know or care which "role" is using them); only
`sender.py` and `receiver.py` differ in *which* packet types they send
vs. wait for.
**Trade-off:** no pipelining — the sender is fully idle while waiting for
each ACK. This is the single biggest throughput cost in the system (see
Problem 3 and §8), traded here for a dramatically simpler, easier-to-get-
correct implementation for a first version.

### Problem 6 — Packet loss, duplicates, and out-of-order arrival
**Why it happens:** ACKs can themselves be lost/garbled (it's the same
lossy optical channel), so a sender may legitimately retransmit a packet
the receiver already has.
**Solution implemented:** every DATA packet's file offset is
`(seq - 1) × PACKET_PAYLOAD_SIZE` — a pure function of its sequence
number, not of arrival order — so writing the same packet twice is a
no-op by construction. The receiver also tracks a `seen` set of
sequence numbers purely so it can skip the disk write and increment a
"duplicates" stat, but even without that check a duplicate write would
be harmless. The same idempotency is applied to ACK/NACK/FINAL_ACK
replies: if the receiver already answered a given sequence number, it
just answers again rather than re-doing the work.
**Trade-off:** none of real consequence — this pattern (content-addressed
writes) is essentially free once you have fixed-size packets and a
disk file you can seek into.

### Problem 7 — Large files and memory
**Why it happens:** spec section 15 requires 10–100 MB+ files without
loading the whole thing into memory.
**Solution implemented:** `sender.py` reads the file `PACKET_PAYLOAD_SIZE`
bytes at a time with a single open file handle (`f.read(...)` in the
per-packet loop). `receiver.py` never buffers received data in memory
either — the destination file is pre-sized once with `f.truncate()`, and
every chunk is written directly with `f.seek(offset); f.write(chunk)`.
Memory use is flat regardless of file size. `integrity.sha256_of_file()`
streams the file through the hash in 1 MB chunks for the same reason.

### Problem 8 — Error correction: FEC vs. ARQ
**Why it matters:** the spec asks about error correction explicitly.
**Decision:** this version uses CRC32 detection + full-packet
retransmission (ARQ), not forward error correction (FEC) at the bit
level. **Trade-off:** a single bit flip anywhere in a frame forces
resending the *whole* ~134-byte packet rather than being locally
repaired in place. Given packets are already small and the channel is
already stop-and-wait, the extra round trip this costs is proportionally
small, and ARQ is dramatically simpler to implement correctly than a
real FEC code (e.g. Reed–Solomon) — a reasonable trade for a first,
correctness-focused version. See §11 for where FEC would plug in later.

---

## 2. Project architecture

```
OptiTransfer/
├── main.py         CLI entry point (the "1. Sender / 2. Receiver" menu)
├── config.py        <-- single source of truth for every tunable constant
├── protocol.py       Packet header layout, PacketType enum, magic bytes
├── packet.py          Packet class: to_bytes()/from_bytes()/CRC32
├── encoder.py           bytes -> optical grid image (+ ArUco markers)
├── decoder.py             camera frame -> perspective-corrected -> bytes
├── camera.py                webcam wrapper + frame-stability polling loop
├── display.py                 on-screen window that shows optical frames
├── integrity.py                  SHA-256 (file) / CRC32 (packet) helpers
├── sender.py           orchestrates: file -> START -> DATA*N -> END
├── receiver.py          orchestrates: calibrate -> decode loop -> verify
├── ui.py                optional Tkinter front end (calls sender/receiver)
├── requirements.txt
├── README.md
└── tests/
    ├── test_packet.py
    ├── test_protocol.py
    ├── test_integrity.py
    ├── test_encoder_decoder.py
    └── test_sequence_logic.py
```

This matches the structure suggested in the spec exactly — it held up
well in practice, so there was no need to deviate from it. Each module
has exactly one job and depends only on the modules below it in the list
above (e.g. `sender.py` uses `camera.py`/`display.py`/`packet.py` but
`packet.py` knows nothing about cameras or screens), which is what makes
the encode/decode pipeline independently unit-testable without any
physical hardware (see `tests/test_encoder_decoder.py`, which simulates
realistic camera photographs entirely in software).

### Data flow

```
 SENDER                                          RECEIVER
 ──────                                          ────────
 file on disk
   │ read chunk (streamed)
   ▼
 Packet(DATA, seq, chunk)
   │ packet.to_bytes()  → MAGIC+VER+TYPE+SEQ+LEN+PAYLOAD+CRC32
   ▼
 encoder.render_packet_frame()  → numpy BGR image (grid + ArUco markers)
   │
   ▼
 display.show_packet()  → cv2 window on sender's screen  ══light══▶  receiver's camera
                                                                          │
                                                            decoder.decode_frame():
                                                              detect_markers()
                                                              → compute_homography()
                                                              → warp_to_canvas()
                                                              → sample_grid()  (Otsu)
                                                              → Packet.from_bytes()  (CRC check)
                                                                          │
                                                       camera.wait_for_packet() requires
                                                       the SAME decode to repeat
                                                       STABILITY_FRAMES times in a row
                                                                          │
                                                                          ▼
                                                       receiver.py: write chunk at
                                                       (seq-1)*PACKET_PAYLOAD_SIZE
                                                                          │
                                                        Packet(ACK, seq) ─┘
   ◀══════════════════════ light ═══════════════════════════════════════
   sender's camera reads it back the same way (decoder/camera reused)
```

---

## 3. The optical protocol

```
+----------+---------+--------+---------+----------+-----------+-----------+
| MAGIC    | VERSION | TYPE   | SEQ     | LENGTH   | PAYLOAD   | CRC32     |
| 4 bytes  | 1 byte  | 1 byte | 4 bytes | 2 bytes  | LENGTH B  | 4 bytes   |
+----------+---------+--------+---------+----------+-----------+-----------+
   "OPTX"      0x01    enum     big-end    big-end   type-      zlib.crc32
                                            unsigned   dependent  over every
                                                                  prior field
```

| Field   | Purpose |
|---|---|
| MAGIC | Software preamble. A decoded grid must start with `OPTX` to even be considered a candidate packet — this is what separates real data from visual noise on a mid-transition or otherwise garbage frame. |
| VERSION | Protocol version, so a future incompatible sender can be rejected cleanly instead of mis-parsed. |
| TYPE | One of `START`, `DATA`, `ACK`, `NACK`, `END`, `FINAL_ACK` (see `protocol.PacketType`). |
| SEQ | `START`=0; `DATA`=1..N (chunk index); `END`=N+1; `ACK`/`NACK`/`FINAL_ACK` echo the SEQ of the packet they respond to. |
| LENGTH | Payload length in bytes. Needed because the optical **grid has fixed physical capacity** (`GRID_COLS×GRID_ROWS` bits) regardless of how much real data a given frame carries — anything beyond `HEADER+LENGTH+CRC32` in the grid is padding the decoder ignores. |
| PAYLOAD | `START`: UTF-8 JSON metadata (`filename`, `extension`, `filesize`, `sha256`, `total_packets`, `packet_payload_size`). `DATA`: raw file chunk. `ACK`/`NACK`/`END`: empty. `FINAL_ACK`: 1 byte, `1`=integrity OK, `0`=integrity FAILED. |
| CRC32 | Packet-level integrity — the fast, per-frame check. |

**Geometric preamble vs. software preamble.** The four ArUco markers
(§1, Problem 2) are the *optical* sync mechanism — they tell the receiver
"a screen is here, and here's its exact orientation." `MAGIC` + `CRC32`
are the *protocol* sync mechanism — they tell the receiver "the bits I
just sampled are real packet data, not a transition frame or the idle
pattern." Requiring both, and requiring the result to be stable across
`STABILITY_FRAMES` consecutive reads, is the full synchronization
strategy (§1, Problem 1).

**Idle frame.** Between transmissions each side shows a checkerboard
"idle" frame (`encoder.render_idle_frame()`) with the ArUco markers still
visible (so "is the screen still in view?" stays answerable) but a
pattern that can never parse as `MAGIC`+valid `CRC32` — see
`tests/test_encoder_decoder.py::test_idle_frame_never_parses_as_a_packet`.

---

## 4. Grid encoding

- Cells: black (`0`) / white (`1`), one bit each — spec's baseline
  request. `config.GRID_COLS × config.GRID_ROWS` (default **40×30 = 1200
  bits = 150 bytes**) is the only place grid size is defined.
- A `CELL_GUTTER_PX`-wide dark border is drawn inside every cell to fight
  bleed between adjacent black/white cells under mild blur.
- Extending to grayscale (e.g. 4 gray levels = 2 bits/cell) or color (RGB
  cells) is architecturally a change to exactly two functions —
  `encoder.render_packet_frame()`'s cell-painting loop and
  `decoder.sample_grid()`'s cell-classification step — because every
  other module only ever deals in `Packet`/bytes, never in pixels
  directly.

---

## 5. Camera processing pipeline (`decoder.py`)

1. **Screen/region detection** — `detect_markers()`: `cv2.aruco` locates
   the 4 corner fiducials.
2. **Corner detection** — the marker corners *are* the corner detection;
   no separate step needed.
3. **Perspective transformation** — `compute_homography()` +
   `warp_to_canvas()`: maps the (possibly tilted/rotated/skewed) camera
   view back to the ideal, undistorted canvas layout.
4. **Cropping** — `sample_grid()` crops to the known grid rectangle within
   that undistorted canvas.
5. **Grid division / cell sampling** — sliced into `GRID_COLS×GRID_ROWS`
   cells; each cell's *central* region (inset from its edges) is
   averaged, avoiding the gutter and any residual warp misalignment.
6. **Thresholding** — Otsu's method over that frame's own cell-mean
   distribution (§1, Problem 4) — effectively adaptive, per-frame
   thresholding without hard-coding a brightness target.

---

## 6. Synchronization strategy (summary)

See §1 Problem 1 for the full reasoning. In one sentence: **hold every
frame on screen far longer than one refresh/exposure cycle, and only
trust a decode once it has reproduced identically for several
consecutive camera reads.**

---

## 7. Calibration

Per spec section 9, `receiver.run_calibration()` runs before any real
decoding: it shows the live camera feed with a "searching... / LOCKED"
indicator (based on `detect_markers()` finding ≥3 of the 4 markers) and
waits for the user to press SPACE/ENTER once positioned correctly (or
Q/ESC to cancel). This was chosen over trying to be fully automatic
because a simple, explicit "is it locked, yes/no" signal the user can
react to is far more robust in practice than a magic auto-detect that
silently starts a transfer from a bad angle and only fails many packets
later.

---

## 8. Performance

Timing at default config (`FRAME_DISPLAY_TIME=0.5s`, `ACK_TIMEOUT=3s`,
`STABILITY_FRAMES=3`, `CAMERA_CAPTURE_INTERVAL=0.04s`, 134 bytes
payload/packet): each successful packet round trip costs roughly
**1–1.5 seconds** (frame hold + stability wait, on both legs of the
exchange), which works out to very approximately:

| Metric | Value |
|---|---|
| Throughput (stop-and-wait, no retries) | ≈ 0.1 KB/s |
| 100 KB file | ≈ 15–20 minutes |
| 1 MB file | ≈ 2.5–3.5 hours |
| 10 MB+ file | many hours |

**This is real, not a placeholder number**, and it is the honest cost of
prioritizing correctness (wide sync margins, full stop-and-wait ARQ, no
FEC) in a first version — see §1 Problem 3/5 for why, and §11 for the
concrete ways to claw a lot of this back once the protocol is proven
correct. For a college demo, sending a small text/JPEG file (a few KB)
is the realistic showcase; the large-file support is architecturally
real (streaming reads/writes, flat memory use — §1 Problem 7) even
though the wall-clock time at default settings makes 50–100 MB files
impractical to actually demo live. `config.py` documents exactly which
knobs (grid size, `FRAME_DISPLAY_TIME`) trade reliability margin for
speed if you want to push it.

The sender/receiver stats screens (spec section 16) report file size,
total/current packet, progress %, elapsed time, live speed, retry count,
and — at the end — average throughput, total retries, and total time
(`sender.TransferStats.summary_text()` / `receiver.ReceiveStats.summary_text()`).

---

## 9. What was actually tested (not just claimed)

`tests/test_encoder_decoder.py` doesn't just check that encode/decode
round-trips on a clean image — it synthesizes a realistic "photograph":
perspective warp + Gaussian blur + Gaussian sensor noise, then decodes
that. Measured results (see §1 Problem 3 for the numbers and how they
were produced) showed 100% success across mild/moderate angles, heavy
blur, noise, and exposure shifts, degrading only under very steep
viewing angles — exactly the case the calibration step (§7) is meant to
catch before a transfer even starts.

---

## 10. Installation

```bash
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

# Linux only, if you'll use the optional GUI (`python main.py --gui`):
sudo apt-get install python3-tk
```

Two laptops, each with a webcam. Run OptiTransfer on both.

## 11. Usage

```bash
python main.py
```
```
========================================
           OPTITRANSFER
========================================
1. Sender
2. Receiver
3. Settings
4. Exit
Select mode:
```

- **On the sending laptop:** choose `1`, then give the path to the file.
  Aim its camera at the receiving laptop's screen, and position its own
  screen so the receiver's camera can see it.
- **On the receiving laptop:** choose `2`, give a folder to save into
  (default `received_files/`), complete calibration (position the camera
  until the on-screen indicator says **LOCKED**, then press SPACE), then
  wait.
- Press **Q** or **ESC** in any OpenCV window at any point to cancel
  cleanly (camera and windows are always released, even on error — see
  §13).
- `python main.py --gui` launches the optional Tkinter front end instead
  (§20 of the spec) — Send/Receive/Settings/Exit buttons, file/folder
  pickers, otherwise identical logic underneath (see `ui.py`'s docstring
  for why the GUI hands off to the same OpenCV windows rather than
  reimplementing the transfer UI in Tkinter).

**Security note (spec section 19):** OptiTransfer never executes a
received file, regardless of its extension (`.exe`, `.bat`, `.sh`,
`.py`, ...). It only writes it to disk. Treat any received file with the
same caution you would apply to any file downloaded from an untrusted
source.

## 12. Testing

```bash
pip install pytest
pytest tests/ -v
```

- `test_packet.py` — serialization round trip, CRC corruption detection,
  bad magic / too-short / oversized-payload rejection, padding tolerance.
- `test_protocol.py` — enum completeness, header struct sizing.
- `test_integrity.py` — SHA-256 (including 5 MB streamed / empty file) and
  CRC32 against Python's own `hashlib`/`zlib` as ground truth.
- `test_encoder_decoder.py` — bit-packing round trip, canvas sizing,
  oversized-payload rejection, no-markers-found handling, the idle frame
  never being mistaken for data, and **5 seeded full optical round trips
  under simulated perspective warp + blur + noise**.
- `test_sequence_logic.py` — metadata JSON round trip, the total-packets
  formula, and a proof that the `(seq-1)*PACKET_PAYLOAD_SIZE` offset
  scheme covers every byte of a file exactly once with no gaps/overlaps
  (the property that makes duplicate/out-of-order packets always safe).

**Manual hardware test plan** (spec section 22), roughly in order:
1. Tiny text file (few hundred bytes — one or two packets) between two
   laptops a comfortable arm's length apart, good lighting, camera
   parallel to the screen.
2. Same setup, 100 KB file — confirms multi-packet looping, progress
   reporting, and several real ACK round trips.
3. Introduce a real angle (~20–30°) and confirm calibration correctly
   shows "searching" until repositioned, then "LOCKED".
4. Partially cover one corner marker with a finger — confirm the
   3-of-4-marker tolerance keeps working, then confirm it correctly
   reports "screen not detected" once 2 or fewer are visible.
5. Dim the room / point a lamp at the screen — confirm the Otsu
   per-frame threshold keeps decoding correctly.
6. Force a NACK: briefly wave a hand across the screen mid-frame and
   confirm the packet gets a retry rather than corrupting the file.
7. Kill the receiver mid-transfer (Q) and confirm the sender eventually
   reports `PACKET #N COULD NOT BE DELIVERED` rather than hanging
   forever.
8. 1 MB binary/image file, letting it run to completion, to confirm
   SHA-256 match end-to-end (accept that this will take a while — see §8).
9. Unplug/disconnect the camera mid-run and confirm a friendly
   `CameraError` message rather than a raw traceback.

## 13. Error handling & safe cancellation

- File errors (missing/unreadable file, permission denied) are caught in
  `sender.FileSender.send_file()` and raised as `SenderError` with a
  human-readable message — never a raw traceback in normal operation.
- Camera errors (unavailable, wrong index, disconnected) raise
  `camera.CameraError`, caught and reported the same way in both
  `main.py` and `ui.py`.
- Optical/protocol errors (bad magic, CRC failure, timeout) never crash
  anything — they flow through `DecodeResult`/retry logic as ordinary,
  expected outcomes, not exceptions.
- Q/ESC in any OpenCV window raises `display.UserCancelled`, caught at
  the top of `sender.send_file()` / `receiver.receive_file()`, which
  always run their camera-release and window-close code in a `finally`
  block — camera, windows, and file handles are released on every exit
  path, including errors and cancellation.
- `main.py`'s outermost `try/except` is a last-resort guard so that even
  a genuinely unexpected bug prints a labeled traceback for debugging
  rather than the interpreter's raw default output.

## 14. Troubleshooting

| Symptom | Likely cause / fix |
|---|---|
| `Could not open camera index 0` | Another app is using the camera, or the index is wrong — try `config.CAMERA_INDEX = 1`, check OS camera permissions. |
| Calibration never shows "LOCKED" | Too far / too dark / too steep an angle. Move closer, improve lighting, aim more directly at the screen. |
| Frequent NACKs / retries | Ambient light flicker, camera autofocus still hunting, or the two screens are too dim/bright relative to each other — try a matte, evenly lit background behind the laptop and increase `FRAME_DISPLAY_TIME` in `config.py`. |
| Transfer very slow | Expected at default settings — see §8. Reduce `FRAME_DISPLAY_TIME`/`ACK_TIMEOUT` cautiously, or increase grid density, once you've confirmed reliability at the defaults first. |
| `tkinter` import error when using `--gui` | Install the OS package: `sudo apt-get install python3-tk` (Linux only; Windows/macOS installers include it). The plain CLI (`python main.py`) doesn't need it at all. |
| `PACKET #N COULD NOT BE DELIVERED` | Optical link was too unreliable for `MAX_RETRIES` in a row — check calibration/lighting and try again; consider raising `MAX_RETRIES` in `config.py`. |

## 15. For a college presentation

**One-sentence pitch:** two laptops exchange a file by literally flashing
a custom black-and-white barcode-like pattern at each other's cameras,
with a full networking-style protocol (headers, sequence numbers, CRC,
ACK/NACK, retries, SHA-256) running on top of that physical light link
instead of Wi-Fi or Bluetooth.

**Good talking points:**
- It's a real (if very slow) instance of a classic networking problem —
  reliable delivery over an unreliable physical layer — solved with the
  same tools real protocols use: framing (MAGIC), checksums (CRC32),
  positive/negative acknowledgement, timeouts, and retransmission.
- The interesting engineering isn't the black/white grid — it's *staying
  synchronized* with a screen and camera that share no clock, and
  *finding and un-distorting* a screen the camera doesn't view head-on.
- It's honest about its own limits: §8 gives real measured throughput
  and §9 gives real measured reliability numbers from simulated,
  reproducible test conditions, not hand-waving.

## 16. Future improvements

- **Sliding-window ACK batching** — the biggest available throughput
  win. Currently one outstanding packet at a time (§1 Problem 5); an
  optical ACK frame that can acknowledge a *range* of sequence numbers
  would let the sender advance several packets between round trips.
- **Grayscale / color cells** — 4-level gray or RGB cells would multiply
  grid capacity by 2–3x per cell without changing the protocol at all,
  only `encoder.render_packet_frame()`/`decoder.sample_grid()` (§4).
- **Forward error correction** — a light FEC code (e.g. Reed–Solomon)
  over each packet's payload would let single/few-bit errors be repaired
  without a full retransmission (§1 Problem 8).
- **Adaptive grid density** — negotiate a denser grid automatically once
  the calibration step confirms a strong, stable, well-lit lock, and fall
  back to a coarser grid automatically if retry rates spike mid-transfer.
- **Multi-camera / multi-monitor** — parallel optical channels between
  additional screen/camera pairs on the same two laptops for genuine
  throughput multiplication.
