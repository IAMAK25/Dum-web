"""
packet.py
=========
The Packet class is the in-memory representation of one protocol frame.
It knows how to serialize itself to bytes (for the encoder) and how to
parse itself back out of bytes (for the decoder), including CRC32
validation.
"""

from __future__ import annotations

import struct
import zlib
from dataclasses import dataclass, field

from protocol import (
    CRC_FMT,
    CRC_SIZE,
    HEADER_FMT,
    HEADER_SIZE,
    MAGIC,
    VERSION,
    PacketType,
    ProtocolError,
)


@dataclass
class Packet:
    type: PacketType
    seq: int
    payload: bytes = b""

    # Populated on decode; not required to construct a packet for sending.
    crc_ok: bool = field(default=True, repr=False, compare=False)

    # ------------------------------------------------------------------ #
    # Serialization
    # ------------------------------------------------------------------ #
    def to_bytes(self) -> bytes:
        """Pack this packet into MAGIC+VERSION+TYPE+SEQ+LENGTH+PAYLOAD+CRC32."""
        if not (0 <= self.seq <= 0xFFFFFFFF):
            raise ValueError(f"seq out of range: {self.seq}")
        if len(self.payload) > 0xFFFF:
            raise ValueError("payload too large for a single packet (>65535 bytes)")

        header = struct.pack(
            HEADER_FMT, MAGIC, VERSION, int(self.type), self.seq, len(self.payload)
        )
        body = header + self.payload
        crc = zlib.crc32(body) & 0xFFFFFFFF
        return body + struct.pack(CRC_FMT, crc)

    # ------------------------------------------------------------------ #
    # Deserialization
    # ------------------------------------------------------------------ #
    @classmethod
    def from_bytes(cls, raw: bytes) -> "Packet":
        """
        Parse `raw` (which may contain trailing padding bytes from the
        fixed-capacity optical grid) into a Packet.

        Raises ProtocolError if MAGIC/VERSION/TYPE are not recognizable --
        this is the cheap, fast rejection path for garbage/transition
        frames. If the structural fields look right but CRC32 fails, we
        still return a Packet (with crc_ok=False) so the caller can
        decide to send a NACK rather than silently dropping the frame.
        """
        if len(raw) < HEADER_SIZE + CRC_SIZE:
            raise ProtocolError("buffer too short for a header+crc")

        magic, version, type_val, seq, length = struct.unpack(
            HEADER_FMT, raw[:HEADER_SIZE]
        )
        if magic != MAGIC:
            raise ProtocolError("bad magic (not an OptiTransfer frame)")
        if version != VERSION:
            raise ProtocolError(f"unsupported protocol version {version}")
        if not PacketType.is_valid(type_val):
            raise ProtocolError(f"unknown packet type {type_val}")

        payload_end = HEADER_SIZE + length
        crc_end = payload_end + CRC_SIZE
        if len(raw) < crc_end:
            raise ProtocolError("buffer too short for declared payload length")

        payload = raw[HEADER_SIZE:payload_end]
        (crc_received,) = struct.unpack(CRC_FMT, raw[payload_end:crc_end])
        crc_computed = zlib.crc32(raw[:payload_end]) & 0xFFFFFFFF

        pkt = cls(type=PacketType(type_val), seq=seq, payload=payload)
        pkt.crc_ok = crc_received == crc_computed
        return pkt

    # ------------------------------------------------------------------ #
    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        ok = "OK" if self.crc_ok else "CRC-FAIL"
        return f"<Packet {self.type.name} seq={self.seq} len={len(self.payload)} {ok}>"
