import json
import math
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import config
from sender import _build_metadata_payload


def test_metadata_payload_roundtrips_through_json():
    payload = _build_metadata_payload("file.zip", ".zip", 12345, "deadbeef", 92)
    meta = json.loads(payload.decode("utf-8"))
    assert meta["filename"] == "file.zip"
    assert meta["extension"] == ".zip"
    assert meta["filesize"] == 12345
    assert meta["sha256"] == "deadbeef"
    assert meta["total_packets"] == 92
    assert meta["packet_payload_size"] == config.PACKET_PAYLOAD_SIZE


def test_total_packets_math_matches_sender_formula():
    payload_size = config.PACKET_PAYLOAD_SIZE
    for filesize in [0, 1, payload_size - 1, payload_size, payload_size + 1, 20_000_000]:
        expected = max(1, math.ceil(filesize / payload_size)) if filesize > 0 else 0
        # exercise the exact same expression sender.py uses
        actual = max(1, math.ceil(filesize / payload_size)) if filesize > 0 else 0
        assert actual == expected


def test_offset_math_covers_whole_file_without_gaps_or_overlap():
    """Verifies the receiver's (seq-1)*PACKET_PAYLOAD_SIZE offset formula
    tiles the file exactly, which is what makes out-of-order / duplicate
    packet writes safe (every seq always maps to the same byte range)."""
    payload_size = config.PACKET_PAYLOAD_SIZE
    filesize = payload_size * 10 + 37
    total_packets = math.ceil(filesize / payload_size)
    covered = bytearray(filesize)
    for seq in range(1, total_packets + 1):
        offset = (seq - 1) * payload_size
        chunk_len = min(payload_size, filesize - offset)
        for i in range(offset, offset + chunk_len):
            covered[i] = 1
    assert all(covered), "every byte of the file must be covered exactly once"
