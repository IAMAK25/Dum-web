import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import protocol
from protocol import PacketType


def test_all_expected_types_present():
    names = {t.name for t in PacketType}
    assert names == {"START", "DATA", "ACK", "NACK", "END", "FINAL_ACK"}


def test_is_valid():
    assert PacketType.is_valid(PacketType.START.value)
    assert not PacketType.is_valid(0xFF)


def test_seq_for_end():
    assert protocol.seq_for_end(100) == 101
    assert protocol.seq_for_end(0) == 1


def test_header_size_matches_struct():
    import struct

    assert struct.calcsize(protocol.HEADER_FMT) == protocol.HEADER_SIZE
