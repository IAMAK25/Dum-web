import hashlib
import os
import sys
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from integrity import crc32_bytes, sha256_of_file


def test_sha256_matches_hashlib_reference():
    data = os.urandom(5_000_000)  # 5 MB, forces multiple streaming chunks
    with tempfile.NamedTemporaryFile(delete=False) as f:
        f.write(data)
        path = f.name
    try:
        expected = hashlib.sha256(data).hexdigest()
        assert sha256_of_file(path) == expected
    finally:
        os.remove(path)


def test_sha256_empty_file():
    with tempfile.NamedTemporaryFile(delete=False) as f:
        path = f.name
    try:
        assert sha256_of_file(path) == hashlib.sha256(b"").hexdigest()
    finally:
        os.remove(path)


def test_crc32_bytes_matches_zlib():
    import zlib

    data = b"the quick brown fox jumps over the lazy dog"
    assert crc32_bytes(data) == (zlib.crc32(data) & 0xFFFFFFFF)
