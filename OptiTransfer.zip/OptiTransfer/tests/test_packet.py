import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest

from packet import Packet
from protocol import PacketType, ProtocolError


def test_roundtrip_data_packet():
    pkt = Packet(PacketType.DATA, seq=42, payload=b"hello world")
    raw = pkt.to_bytes()
    decoded = Packet.from_bytes(raw)
    assert decoded.type == PacketType.DATA
    assert decoded.seq == 42
    assert decoded.payload == b"hello world"
    assert decoded.crc_ok is True


def test_roundtrip_empty_payload():
    pkt = Packet(PacketType.ACK, seq=3)
    raw = pkt.to_bytes()
    decoded = Packet.from_bytes(raw)
    assert decoded.payload == b""
    assert decoded.crc_ok is True


def test_crc_detects_corruption():
    pkt = Packet(PacketType.DATA, seq=1, payload=b"important bytes")
    raw = bytearray(pkt.to_bytes())
    raw[15] ^= 0xFF  # flip bits inside the payload
    decoded = Packet.from_bytes(bytes(raw))
    assert decoded.crc_ok is False


def test_bad_magic_raises():
    junk = b"XXXX" + b"\x00" * 20
    with pytest.raises(ProtocolError):
        Packet.from_bytes(junk)


def test_too_short_raises():
    with pytest.raises(ProtocolError):
        Packet.from_bytes(b"short")


def test_trailing_padding_is_ignored():
    """Grid capacity is fixed, so packets are followed by padding bytes;
    the decoder must only look at HEADER+LENGTH+CRC and ignore the rest."""
    pkt = Packet(PacketType.NACK, seq=9)
    raw = pkt.to_bytes() + b"\x00" * 100  # simulate unused grid capacity
    decoded = Packet.from_bytes(raw)
    assert decoded.crc_ok is True
    assert decoded.seq == 9


def test_seq_out_of_range_rejected():
    pkt = Packet(PacketType.DATA, seq=2**32, payload=b"x")
    with pytest.raises(ValueError):
        pkt.to_bytes()


def test_payload_too_large_rejected():
    pkt = Packet(PacketType.DATA, seq=1, payload=b"x" * 70000)
    with pytest.raises(ValueError):
        pkt.to_bytes()
