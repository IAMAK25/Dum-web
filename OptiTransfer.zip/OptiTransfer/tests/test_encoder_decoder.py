import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import cv2
import numpy as np
import pytest

import config
import decoder
import encoder
from packet import Packet
from protocol import PacketType


def test_bits_bytes_roundtrip():
    data = os.urandom(37)
    bits = encoder.bytes_to_bits(data, len(data) * 8)
    back = encoder.bits_to_bytes(bits)
    assert back == data


def test_render_packet_frame_has_expected_canvas_size():
    pkt = Packet(PacketType.ACK, seq=1)
    frame = encoder.render_packet_frame(pkt)
    w, h = config.canvas_size_px()
    assert frame.shape[:2] == (h, w)


def test_oversized_payload_rejected_before_rendering():
    pkt = Packet(PacketType.DATA, seq=1, payload=b"x" * (config.GRID_CAPACITY_BYTES + 10))
    with pytest.raises(ValueError):
        encoder.render_packet_frame(pkt)


def test_decode_frame_with_no_markers_returns_none():
    blank = np.full((480, 640, 3), 127, dtype=np.uint8)
    result = decoder.decode_frame(blank)
    assert result.packet is None
    assert result.markers_found == 0


def _simulate_photo(canvas: np.ndarray, seed: int) -> np.ndarray:
    """
    Warp/blur/noise a rendered canvas to approximate a real webcam photo of
    a laptop screen viewed at a mild-to-moderate angle under normal
    lighting, with the screen properly framed (fully inside the shot) --
    i.e. what a user should see once `receiver.run_calibration()` reports
    "LOCKED". Very steep off-axis angles or a screen that isn't fully in
    frame are a separate, expected failure mode (see README.md section 1,
    Problem 2/3) that calibration exists specifically to prevent before a
    real transfer ever starts, so this test intentionally stays within
    that "properly calibrated" envelope rather than testing mis-framing.

    NOTE: `borderValue` below is filled with the same mid-gray as the
    canvas background (config.BACKGROUND_GRAY) rather than an arbitrary
    dark color -- using a much darker fill here would let a corner
    marker's black border visually blend into the synthetic "outside the
    photographed canvas" padding at extreme jitter values, which is an
    artifact of this simulation technique (warpPerspective needs *some*
    fill color for pixels outside the source image), not a real-world
    camera effect, and was confirmed by direct debugging during
    development (see README.md section 9).
    """
    import config as _config

    h, w = canvas.shape[:2]
    rng = np.random.default_rng(seed)
    src = np.float32([[0, 0], [w, 0], [w, h], [0, h]])
    jitter = rng.uniform(-0.05, 0.05, size=(4, 2)) * np.array([w, h])
    dst = (src + jitter + rng.uniform(-20, 20, size=(4, 2))).astype(np.float32)
    H = cv2.getPerspectiveTransform(src, dst)
    bg = (_config.BACKGROUND_GRAY,) * 3
    photo = cv2.warpPerspective(canvas, H, (w + 250, h + 250), borderValue=bg)
    photo = cv2.GaussianBlur(photo, (3, 3), 0)
    noise = rng.normal(0, 5, photo.shape).astype(np.int16)
    photo = np.clip(photo.astype(np.int16) + noise, 0, 255).astype(np.uint8)
    return photo


@pytest.mark.parametrize("seed", list(range(15)))
def test_full_optical_roundtrip_under_distortion(seed):
    """This is the test that matters most: encode a packet, simulate a
    realistic camera photograph of it (perspective skew + blur + noise),
    and confirm the decoder reconstructs the exact original packet."""
    payload = os.urandom(config.PACKET_PAYLOAD_SIZE)
    pkt = Packet(PacketType.DATA, seq=123, payload=payload)
    canvas = encoder.render_packet_frame(pkt)
    photo = _simulate_photo(canvas, seed)

    result = decoder.decode_frame(photo)
    assert result.packet is not None, f"failed to decode at all (seed={seed})"
    assert result.packet.crc_ok, f"CRC failed after distortion (seed={seed})"
    assert result.packet.seq == 123
    assert result.packet.payload == payload


def test_idle_frame_never_parses_as_a_packet():
    """The idle/checkerboard frame must never be mistaken for real data,
    even though the markers are fully visible."""
    idle = encoder.render_idle_frame()
    result = decoder.decode_frame(idle)
    assert result.packet is None or result.packet.crc_ok is False
