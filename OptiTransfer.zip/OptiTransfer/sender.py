"""
sender.py
=========
Implements the sender side of spec section 4: read the file, describe
it in a START packet, stream it as DATA packets under a stop-and-wait
ARQ (send -> wait for optical ACK/NACK -> retry or advance), then END.

Stop-and-wait (one packet in flight at a time) was chosen over a
sliding window for this first version because the whole channel is
already forced to be strictly half-duplex by physics: only one screen
can be "the one the other laptop's camera is looking at" at a time, and
switching which laptop is transmitting requires a display/camera
role-swap. A sliding window would need a way to pack multiple
outstanding sequence numbers' acknowledgements into a single optical
ACK frame, which is a legitimate future optimization (see README ->
Future Improvements) but adds real complexity for a first, correctness
-focused version. See README -> "Performance" for the resulting
throughput and why it is what it is.
"""

from __future__ import annotations

import json
import math
import os
import time
from dataclasses import dataclass, field
from typing import Optional

import camera as camera_mod
import config
from display import OpticalDisplay, UserCancelled
from integrity import sha256_of_file
from packet import Packet
from protocol import PacketType, seq_for_end


class SenderError(Exception):
    pass


@dataclass
class TransferStats:
    filename: str = ""
    filesize: int = 0
    total_packets: int = 0
    packets_sent: int = 0
    retries: int = 0
    start_time: float = 0.0
    end_time: float = 0.0
    sha256: str = ""
    success: bool = False
    failure_reason: str = ""

    def summary_text(self) -> str:
        elapsed = self.end_time - self.start_time
        speed = (self.filesize / 1024) / elapsed if elapsed > 0 else 0.0
        if self.success:
            lines = [
                "Transfer completed successfully.",
                f"File: {self.filename}",
                f"Size: {self.filesize / (1024*1024):.2f} MB",
                f"Packets: {self.total_packets}",
                f"Retries: {self.retries}",
                f"Time: {int(elapsed // 60)}m {elapsed % 60:.0f}s",
                f"Average speed: {speed:.1f} KB/s",
                f"SHA-256: {self.sha256}",
            ]
        else:
            lines = [
                "TRANSFER FAILED",
                self.failure_reason,
                f"Packets sent before failure: {self.packets_sent}/{self.total_packets}",
                f"Retries: {self.retries}",
            ]
        return "\n".join(lines)


def _build_metadata_payload(filename, extension, filesize, sha256, total_packets) -> bytes:
    meta = {
        "filename": filename,
        "extension": extension,
        "filesize": filesize,
        "sha256": sha256,
        "total_packets": total_packets,
        "packet_payload_size": config.PACKET_PAYLOAD_SIZE,
    }
    return json.dumps(meta, separators=(",", ":")).encode("utf-8")


class FileSender:
    def __init__(self, on_progress=None):
        """on_progress(stats: TransferStats) is called after every packet
        (sent or retried) so a UI can render a live progress bar."""
        self.on_progress = on_progress
        self.display: Optional[OpticalDisplay] = None
        self.cam: Optional[camera_mod.Camera] = None

    # ------------------------------------------------------------------ #
    def _transmit_with_retry(
        self, packet: Packet, ack_types: set, label: str
    ) -> tuple[Optional[Packet], int]:
        """Display `packet` and wait for an optical response of a type in
        `ack_types`. A NACK (or timeout) triggers a retry. Returns
        (response_packet_or_None, retries_used)."""
        retries_used = 0
        for attempt in range(config.MAX_RETRIES + 1):
            self.display.show_packet(packet, config.FRAME_DISPLAY_TIME)
            resp = camera_mod.wait_for_packet(
                self.cam,
                preview_window="OptiTransfer - Sender Camera (watching for ACK)",
                expected_types=ack_types | {PacketType.NACK},
                expected_seq=packet.seq,
                timeout=config.ACK_TIMEOUT,
                status_line=f"{label}  seq={packet.seq}  attempt {attempt + 1}/{config.MAX_RETRIES + 1}",
            )
            self.display.show_idle()
            if resp is not None and resp.type in ack_types:
                return resp, retries_used
            # timeout or NACK -> retry
            retries_used += 1
        return None, retries_used - 1

    # ------------------------------------------------------------------ #
    def send_file(self, filepath: str) -> TransferStats:
        stats = TransferStats()
        if not os.path.isfile(filepath):
            raise SenderError(f"File does not exist: {filepath}")
        if not os.access(filepath, os.R_OK):
            raise SenderError(f"Permission denied reading: {filepath}")

        filesize = os.path.getsize(filepath)
        filename = os.path.basename(filepath)
        extension = os.path.splitext(filename)[1]
        stats.filename = filename
        stats.filesize = filesize

        # Full-file SHA-256, streamed (spec section 15: no full in-memory copies).
        file_hash = sha256_of_file(filepath)
        stats.sha256 = file_hash

        total_packets = max(1, math.ceil(filesize / config.PACKET_PAYLOAD_SIZE)) if filesize > 0 else 0
        stats.total_packets = total_packets

        self.display = OpticalDisplay("OptiTransfer - Sender Screen")
        self.cam = camera_mod.Camera()
        self.cam.open()
        stats.start_time = time.monotonic()

        try:
            # ---- START -----------------------------------------------
            meta_payload = _build_metadata_payload(
                filename, extension, filesize, file_hash, total_packets
            )
            start_pkt = Packet(PacketType.START, seq=0, payload=meta_payload)
            resp, retries = self._transmit_with_retry(
                start_pkt, ack_types={PacketType.ACK}, label="Sending START"
            )
            stats.retries += retries
            if resp is None:
                stats.failure_reason = "Receiver never acknowledged START (file metadata)."
                self._finish(stats, success=False)
                return stats

            # ---- DATA --------------------------------------------------
            with open(filepath, "rb") as f:
                for seq in range(1, total_packets + 1):
                    chunk = f.read(config.PACKET_PAYLOAD_SIZE)
                    data_pkt = Packet(PacketType.DATA, seq=seq, payload=chunk)
                    resp, retries = self._transmit_with_retry(
                        data_pkt,
                        ack_types={PacketType.ACK},
                        label=f"Sending DATA {seq}/{total_packets}",
                    )
                    stats.retries += retries
                    if resp is None:
                        stats.failure_reason = (
                            f"PACKET #{seq} COULD NOT BE DELIVERED "
                            f"after {config.MAX_RETRIES} retries."
                        )
                        stats.packets_sent = seq - 1
                        self._finish(stats, success=False)
                        return stats
                    stats.packets_sent = seq
                    if self.on_progress:
                        self.on_progress(stats)

            # ---- END -----------------------------------------------------
            end_pkt = Packet(PacketType.END, seq=seq_for_end(total_packets), payload=b"")
            resp, retries = self._transmit_with_retry(
                end_pkt, ack_types={PacketType.FINAL_ACK}, label="Sending END"
            )
            stats.retries += retries
            if resp is None:
                stats.failure_reason = "Receiver never sent FINAL_ACK after END."
                self._finish(stats, success=False)
                return stats

            integrity_ok = bool(resp.payload) and resp.payload[0] == 1
            if not integrity_ok:
                stats.failure_reason = (
                    "Receiver reported FILE INTEGRITY CHECK FAILED (SHA-256 mismatch)."
                )
                self._finish(stats, success=False)
                return stats

            self._finish(stats, success=True)
            return stats

        except UserCancelled:
            stats.failure_reason = "Cancelled by user."
            self._finish(stats, success=False)
            return stats
        finally:
            self.cam.release()
            self.display.close()

    @staticmethod
    def _finish(stats: TransferStats, success: bool) -> None:
        stats.success = success
        stats.end_time = time.monotonic()
