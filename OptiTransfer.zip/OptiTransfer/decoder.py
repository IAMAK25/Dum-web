"""
decoder.py
==========
The inverse of encoder.py: given one raw camera frame, try to locate the
sender's screen, correct for perspective/tilt, sample the black/white
grid, and reconstruct a Packet.

Pipeline (spec section 9):
    1. Detect the four ArUco corner markers  -> screen/region detection
    2. Build a homography from detected marker corners (camera space) to
       their known ideal positions (canvas space)          -> corner detection
    3. Warp the camera frame through that homography        -> perspective
                                                                 transformation
    4. Crop to the known grid rectangle                      -> cropping
    5. Slice into GRID_COLS x GRID_ROWS cells                -> grid division
    6. Sample each cell's mean intensity                     -> cell sampling
    7. Otsu-threshold the cell-mean array into 0/1 bits       -> thresholding
    8. Pack bits -> bytes -> Packet.from_bytes                -> CRC check

This module never raises on "no screen visible" / "bad frame" -- it
returns a DecodeResult with packet=None so camera.py's polling loop can
just keep trying. It only raises for genuine programmer errors.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import cv2
import numpy as np

import config
from encoder import ARUCO_DICT, canvas_reference_corners, grid_rect, _layout
from packet import Packet
from protocol import ProtocolError


@dataclass
class DecodeResult:
    packet: Optional[Packet]
    markers_found: int
    warped: Optional[np.ndarray] = None  # for live-preview debugging only
    reason: str = ""  # human-readable status for the UI/stats overlay


_ARUCO_PARAMS = cv2.aruco.DetectorParameters()
_ARUCO_DETECTOR = cv2.aruco.ArucoDetector(ARUCO_DICT, _ARUCO_PARAMS)


def detect_markers(frame_bgr: np.ndarray) -> dict:
    """Returns {marker_id: (4,2) float32 corner array in camera pixel space}."""
    gray = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2GRAY)
    corners, ids, _ = _ARUCO_DETECTOR.detectMarkers(gray)
    found = {}
    if ids is not None:
        for c, i in zip(corners, ids.flatten()):
            if int(i) in config.MARKER_IDS:
                found[int(i)] = c.reshape(4, 2).astype(np.float32)
    return found


def compute_homography(detected: dict) -> Optional[np.ndarray]:
    """
    Build a camera->canvas homography from however many marker corners
    were detected. We require at least 3 of the 4 markers (12 of 16
    possible correspondence points) so a partially-occluded view can
    still work, but we do NOT attempt a homography from a single marker
    -- four coplanar points from one small marker produce a numerically
    unstable transform once extrapolated across the whole canvas.
    """
    if len(detected) < 3:
        return None

    ref = canvas_reference_corners()
    src_pts, dst_pts = [], []
    for marker_id, cam_corners in detected.items():
        src_pts.append(cam_corners)
        dst_pts.append(ref[marker_id])
    src_pts = np.concatenate(src_pts, axis=0)
    dst_pts = np.concatenate(dst_pts, axis=0)

    H, _mask = cv2.findHomography(src_pts, dst_pts, method=cv2.RANSAC)
    return H


def warp_to_canvas(frame_bgr: np.ndarray, H: np.ndarray) -> np.ndarray:
    layout = _layout()
    return cv2.warpPerspective(frame_bgr, H, (layout["canvas_w"], layout["canvas_h"]))


def sample_grid(canvas_img: np.ndarray) -> np.ndarray:
    """
    Slice the warped canvas into GRID_COLS x GRID_ROWS cells and return a
    (rows, cols) uint8 array of 0/1 bits.

    Each cell is sampled from its central region only (shrinking inward
    by CELL_GUTTER_PX plus a small extra margin) to avoid the dark
    gutter the encoder draws between cells and to reduce sensitivity to
    slight residual misalignment after the perspective warp.
    """
    gx, gy, gw, gh = grid_rect()
    grid_region = canvas_img[gy : gy + gh, gx : gx + gw]
    gray = cv2.cvtColor(grid_region, cv2.COLOR_BGR2GRAY)

    cell = config.CELL_SIZE_PX
    inset = max(config.CELL_GUTTER_PX + 2, int(cell * 0.25))
    means = np.zeros((config.GRID_ROWS, config.GRID_COLS), dtype=np.float32)

    for r in range(config.GRID_ROWS):
        for c in range(config.GRID_COLS):
            y0, x0 = r * cell + inset, c * cell + inset
            y1, x1 = (r + 1) * cell - inset, (c + 1) * cell - inset
            if y1 <= y0 or x1 <= x0:
                y0, x0, y1, x1 = r * cell, c * cell, (r + 1) * cell, (c + 1) * cell
            means[r, c] = gray[y0:y1, x0:x1].mean()

    # Otsu over the *cell means* (not the raw pixels) -- this adapts to
    # whatever brightness range the ambient lighting/camera produced,
    # rather than assuming fixed 0/255 targets.
    means_u8 = cv2.normalize(means, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    _thresh_val, binary = cv2.threshold(
        means_u8, 0, 1, cv2.THRESH_BINARY + cv2.THRESH_OTSU
    )
    return binary.astype(np.uint8)


def decode_frame(frame_bgr: np.ndarray) -> DecodeResult:
    detected = detect_markers(frame_bgr)
    if len(detected) < 3:
        return DecodeResult(
            packet=None, markers_found=len(detected), reason="screen not detected"
        )

    H = compute_homography(detected)
    if H is None:
        return DecodeResult(
            packet=None, markers_found=len(detected), reason="homography failed"
        )

    warped = warp_to_canvas(frame_bgr, H)
    bits = sample_grid(warped)

    # Local import to avoid a circular import at module load time.
    from encoder import bits_to_bytes

    raw = bits_to_bytes(bits.flatten())

    try:
        pkt = Packet.from_bytes(raw)
    except ProtocolError as exc:
        return DecodeResult(
            packet=None,
            markers_found=len(detected),
            warped=warped,
            reason=f"no valid frame ({exc})",
        )

    if not pkt.crc_ok:
        return DecodeResult(
            packet=pkt, markers_found=len(detected), warped=warped, reason="CRC fail"
        )

    return DecodeResult(packet=pkt, markers_found=len(detected), warped=warped, reason="ok")
