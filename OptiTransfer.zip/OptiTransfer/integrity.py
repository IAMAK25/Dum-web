"""
integrity.py
============
Two levels of integrity checking, per spec section 13:

  * Packet level  -> CRC32, handled inline in packet.py (cheap, fast,
    catches the vast majority of optical bit-flip errors per frame).
  * File level    -> SHA-256 over the complete reassembled file,
    computed by both sides and compared during the END/FINAL_ACK
    handshake. This is the authoritative "did the whole transfer
    actually work" check.

All file reads here are streamed in fixed-size chunks so we never load
an entire large file into memory at once (spec section 15).
"""

import hashlib
import zlib

CHUNK_SIZE = 1024 * 1024  # 1 MB streaming read size for hashing


def sha256_of_file(path: str) -> str:
    """Stream a file through SHA-256 without loading it all into memory."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(CHUNK_SIZE)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def crc32_bytes(data: bytes) -> int:
    return zlib.crc32(data) & 0xFFFFFFFF
