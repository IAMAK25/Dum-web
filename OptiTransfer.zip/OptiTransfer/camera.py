"""
camera.py
=========
Owns the physical webcam and implements the receiving side of the
synchronization strategy described in README.md ("Problem 1: screen /
camera tearing").

Core idea: a single successful decode (valid MAGIC + passing CRC32) is
NOT enough evidence that the screen has settled -- a camera can, in
principle, photograph a frame mid-redraw and still happen to sample
something that parses. So instead we require the *same* decoded
(type, seq, payload) to reproduce across STABILITY_FRAMES consecutive
camera reads before we trust it. Combined with the sender holding each
frame on screen for FRAME_DISPLAY_TIME (comfortably longer than one
screen refresh + one camera exposure interval), a torn/transitional
capture will almost always either fail to decode at all, or decode to
something that does NOT reproduce on the next read -- so the stability
counter resets and we simply try again a few milliseconds later.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Iterable, Optional

import cv2

import config
from decoder import decode_frame
from display import CANCEL_KEYS, UserCancelled
from packet import Packet
from protocol import PacketType


class CameraError(Exception):
    pass


class Camera:
    def __init__(self, index: int = config.CAMERA_INDEX):
        self.index = index
        self.cap: Optional[cv2.VideoCapture] = None

    def open(self) -> None:
        self.cap = cv2.VideoCapture(self.index)
        if not self.cap.isOpened():
            raise CameraError(
                f"Could not open camera index {self.index}. Check that no other "
                f"application is using it and that camera permissions are granted."
            )
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, config.CAMERA_CAPTURE_WIDTH)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, config.CAMERA_CAPTURE_HEIGHT)

    def read(self):
        if self.cap is None:
            raise CameraError("Camera not open")
        ok, frame = self.cap.read()
        if not ok or frame is None:
            return None
        return frame

    def release(self) -> None:
        if self.cap is not None:
            self.cap.release()
            self.cap = None


@dataclass
class WaitStats:
    frames_read: int = 0
    decode_attempts_ok: int = 0
    elapsed: float = 0.0


def _signature(pkt: Packet):
    return (pkt.type, pkt.seq, pkt.payload, pkt.crc_ok)


def wait_for_packet(
    camera: Camera,
    preview_window: str,
    expected_types: Optional[Iterable[PacketType]] = None,
    expected_seq: Optional[int] = None,
    timeout: Optional[float] = config.IDLE_WAIT_TIMEOUT,
    stability_frames: int = config.STABILITY_FRAMES,
    status_line: str = "",
) -> Optional[Packet]:
    """
    Poll the camera until a packet decodes identically `stability_frames`
    times in a row (optionally filtered to `expected_types` / `expected_seq`),
    or until `timeout` seconds elapse (None = wait forever, still
    cancellable with Q/ESC).

    Also drives a live preview window (spec section 5.2) with an overlay
    showing marker/lock status, which doubles as the "screen detected"
    indicator required by the receiver UI in spec section 20.
    """
    expected_types = set(expected_types) if expected_types is not None else None
    last_sig = None
    stable_count = 0
    start = time.monotonic()
    stats = WaitStats()

    cv2.namedWindow(preview_window, cv2.WINDOW_NORMAL)

    while True:
        if timeout is not None and (time.monotonic() - start) > timeout:
            return None

        frame = camera.read()
        stats.frames_read += 1
        if frame is None:
            _draw_and_show(preview_window, None, 0, "camera read failed", status_line)
            key = cv2.waitKey(1) & 0xFF
            if key in CANCEL_KEYS:
                raise UserCancelled()
            time.sleep(config.CAMERA_CAPTURE_INTERVAL)
            continue

        result = decode_frame(frame)
        preview_reason = result.reason
        matched_filter = True
        if result.packet is not None:
            stats.decode_attempts_ok += 1
            if expected_types is not None and result.packet.type not in expected_types:
                matched_filter = False
                preview_reason = f"ignoring {result.packet.type.name} (not expected)"
            if expected_seq is not None and result.packet.seq != expected_seq:
                matched_filter = False
                preview_reason = (
                    f"ignoring seq={result.packet.seq} (want {expected_seq})"
                )

        if result.packet is not None and matched_filter:
            sig = _signature(result.packet)
            if sig == last_sig:
                stable_count += 1
            else:
                stable_count = 1
                last_sig = sig
        else:
            stable_count = 0
            last_sig = None

        _draw_and_show(
            preview_window,
            frame,
            result.markers_found,
            preview_reason,
            status_line,
            stable_count,
            stability_frames,
        )

        key = cv2.waitKey(1) & 0xFF
        if key in CANCEL_KEYS:
            raise UserCancelled()

        if stable_count >= stability_frames:
            return result.packet

        time.sleep(config.CAMERA_CAPTURE_INTERVAL)


def _draw_and_show(
    window: str,
    frame,
    markers_found: int,
    reason: str,
    status_line: str,
    stable_count: int = 0,
    stability_frames: int = config.STABILITY_FRAMES,
) -> None:
    import numpy as np

    if frame is None:
        frame = np.zeros((360, 640, 3), dtype="uint8")
    else:
        frame = frame.copy()

    lock = "LOCKED" if markers_found >= 3 else "NO SCREEN"
    lines = [
        status_line,
        f"Screen: {lock} ({markers_found}/4 markers)  Stability: {stable_count}/{stability_frames}",
        f"Last frame: {reason}",
        "Press Q or ESC to cancel",
    ]
    y = 24
    for line in lines:
        if not line:
            continue
        cv2.putText(
            frame, line, (10, y), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 0, 0), 3
        )
        cv2.putText(
            frame, line, (10, y), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 255, 0), 1
        )
        y += 24

    cv2.imshow(window, frame)
