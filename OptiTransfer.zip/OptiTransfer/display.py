"""
display.py
===========
Owns the OpenCV window that shows optical frames on THIS laptop's
screen (data frames when acting as sender, ACK/NACK frames when acting
as receiver -- the roles are symmetric at the display/camera level).

Kept deliberately dumb: it knows how to put a numpy image on screen and
hold it for a given duration while still pumping the window's event
loop (so it doesn't look "frozen" to the OS and so Q/ESC can be
detected immediately rather than only after the hold expires).
"""

from __future__ import annotations

import time
from typing import Optional

import cv2
import numpy as np

import encoder
from packet import Packet


CANCEL_KEYS = {27, ord("q"), ord("Q")}  # ESC or Q


class UserCancelled(Exception):
    """Raised when the user presses Q/ESC during a blocking display/wait."""


class OpticalDisplay:
    def __init__(self, window_name: str = "OptiTransfer - Screen", fullscreen: bool = False):
        self.window_name = window_name
        cv2.namedWindow(self.window_name, cv2.WINDOW_NORMAL)
        if fullscreen:
            cv2.setWindowProperty(
                self.window_name, cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN
            )
        else:
            layout_w, layout_h = encoder._layout()["canvas_w"], encoder._layout()["canvas_h"]
            cv2.resizeWindow(self.window_name, layout_w, layout_h)
        self._last_frame: Optional[np.ndarray] = None

    # ------------------------------------------------------------------ #
    def _show(self, frame: np.ndarray, hold_time: float) -> None:
        """Show `frame` and block for `hold_time` seconds, pumping events."""
        self._last_frame = frame
        cv2.imshow(self.window_name, frame)
        deadline = time.monotonic() + hold_time
        while time.monotonic() < deadline:
            remaining_ms = max(1, int((deadline - time.monotonic()) * 1000))
            key = cv2.waitKey(min(remaining_ms, 30)) & 0xFF
            if key in CANCEL_KEYS:
                raise UserCancelled()

    def show_packet(self, packet: Packet, hold_time: float) -> None:
        frame = encoder.render_packet_frame(packet)
        self._show(frame, hold_time)

    def show_idle(self, hold_time: float = 0.05) -> None:
        frame = encoder.render_idle_frame()
        self._show(frame, hold_time)

    def pump(self) -> None:
        """Call periodically during long blocking waits to keep the window
        responsive and to raise UserCancelled if Q/ESC was pressed, without
        changing what's currently displayed."""
        key = cv2.waitKey(1) & 0xFF
        if key in CANCEL_KEYS:
            raise UserCancelled()

    def close(self) -> None:
        try:
            cv2.destroyWindow(self.window_name)
        except cv2.error:
            pass
