import os
import time
import cv2
from .camera import Camera
from .integrity import sha256_file
from .protocol import FrameType, pack_frame
from .qr import QRCodec
from .stopwait import StopAndWaitSender

class Sender:
    def __init__(self, config):
        self.config = config
        self.qr = QRCodec(config)
        self.camera = Camera(config)
        self.arq = StopAndWaitSender(config, self.qr, self.camera)

    def run(self, path):
        path = os.path.abspath(os.path.expanduser(path))
        if not os.path.isfile(path):
            raise FileNotFoundError(f'File does not exist: {path}')
        size = os.path.getsize(path)
        digest = sha256_file(path)
        chunk_size = self.config.payload_bytes
        total = max(1, (size + chunk_size - 1) // chunk_size)
        metadata = (f'name={os.path.basename(path)}\nsize={size}\nsha256={digest}\n').encode('utf-8')
        qr_window = 'OptiTransfer - SENDER QR'
        camera_window = 'OptiTransfer - SENDER ACK CAMERA'
        cv2.namedWindow(qr_window, cv2.WINDOW_NORMAL)
        cv2.namedWindow(camera_window, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(qr_window, self.config.qr_size, self.config.qr_size)
        self.camera.open()
        try:
            print('\n' + '=' * 72)
            print('             OPTITRANSFER QR SENDER')
            print('             STRICT STOP-AND-WAIT')
            print('=' * 72)
            print(f'File       : {path}')
            print(f'Size       : {size:,} bytes')
            print(f'Payload/QR : {chunk_size:,} bytes')
            print(f'DATA count : {total:,}')
            print(f'SHA-256    : {digest}')
            print('=' * 72)
            input('Start receiver first, then press ENTER...')
            start = pack_frame(FrameType.START, 0, total, metadata)
            if not self.arq.send_packet(qr_window, camera_window, start, 0, 'START'):
                raise RuntimeError('START handshake failed.')
            started = time.monotonic()
            sent_packets = 0
            sent_bytes = 0
            with open(path, 'rb') as file:
                while True:
                    chunk = file.read(chunk_size)
                    if not chunk:
                        break
                    frame = pack_frame(FrameType.DATA, sent_packets, total, chunk)
                    if not self.arq.send_packet(qr_window, camera_window, frame, sent_packets, 'DATA'):
                        raise RuntimeError(f'DATA #{sent_packets} failed after retries.')
                    sent_packets += 1
                    sent_bytes += len(chunk)
                    elapsed = max(time.monotonic() - started, 0.001)
                    print(f'Progress: {sent_packets}/{total} ({sent_packets*100/total:6.2f}%) {sent_bytes/elapsed/1024:,.1f} KB/s')
            end = pack_frame(FrameType.END, total, total)
            if not self.arq.send_packet(qr_window, camera_window, end, total, 'END'):
                raise RuntimeError('END was not acknowledged.')
            elapsed = max(time.monotonic() - started, 0.001)
            print('\n' + '=' * 72)
            print('                 TRANSFER COMPLETE')
            print('=' * 72)
            print(f'Packets : {sent_packets:,}')
            print(f'Bytes   : {sent_bytes:,}')
            print(f'Time    : {elapsed:.2f} seconds')
            print(f'Retries : {self.arq.retries}')
            print(f'SHA256  : {digest}')
            print('=' * 72)
            input('Press ENTER to return...')
        finally:
            self.camera.close()
            cv2.destroyAllWindows()
