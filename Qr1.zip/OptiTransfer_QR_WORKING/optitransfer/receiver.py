import os
import time
import cv2
from .camera import Camera
from .integrity import sha256_file
from .protocol import FrameType, pack_frame, unpack_frame
from .qr import QRCodec

class Receiver:
    def __init__(self, config):
        self.config = config
        self.qr = QRCodec(config)
        self.camera = Camera(config)
        self.started = False
        self.total = None
        self.metadata = {}
        self.last_data = -1
        self.packets = {}

    def show_ack(self, ack_window, sequence, ack=True):
        kind = FrameType.ACK if ack else FrameType.NACK
        frame = pack_frame(kind, sequence, self.total or 0)
        cv2.imshow(ack_window, self.qr.encode(frame))
        cv2.waitKey(1)
        print(f'-> {"ACK" if ack else "NACK"} #{sequence}')
        time.sleep(self.config.qr_hold_s)

    def run(self):
        camera_window = 'OptiTransfer - RECEIVER CAMERA'
        ack_window = 'OptiTransfer - RECEIVER ACK QR'
        cv2.namedWindow(camera_window, cv2.WINDOW_NORMAL)
        cv2.namedWindow(ack_window, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(camera_window, 900, 600)
        cv2.resizeWindow(ack_window, self.config.qr_size, self.config.qr_size)
        self.camera.open()
        print('\n' + '=' * 72)
        print('            OPTITRANSFER QR RECEIVER')
        print('            STRICT STOP-AND-WAIT')
        print('=' * 72)
        print('CAMERA ACTIVE - live preview is opening.')
        print('Point this camera at the SENDER QR window.')
        print('Waiting for START...')
        print('=' * 72)
        try:
            while True:
                frame = self.camera.read()
                preview = self.qr.draw_overlay(frame, 'CAMERA ACTIVE - SEARCHING FOR QR...')
                cv2.imshow(camera_window, preview)
                key = cv2.waitKey(self.config.camera_poll_ms) & 0xFF
                if key in (27, ord('q'), ord('Q')):
                    print('Receiver cancelled.')
                    return
                raw = self.qr.decode(frame)
                if raw is None:
                    continue
                parsed = unpack_frame(raw)
                if parsed is None:
                    print('QR detected, but protocol/CRC validation failed.')
                    continue
                kind = parsed['type']
                sequence = parsed['sequence']
                print(f'QR DETECTED: {kind.name} #{sequence}')
                if kind == FrameType.START:
                    self.handle_start(parsed, ack_window)
                elif kind == FrameType.DATA:
                    self.handle_data(parsed, ack_window)
                elif kind == FrameType.END:
                    if self.handle_end(parsed, ack_window):
                        break
        finally:
            self.camera.close()
            cv2.destroyAllWindows()
        input('Press ENTER to return...')

    def handle_start(self, parsed, ack_window):
        if parsed['sequence'] != 0:
            self.show_ack(ack_window, parsed['sequence'], False)
            return
        try:
            text = parsed['payload'].decode('utf-8')
            metadata = {}
            for line in text.splitlines():
                if '=' in line:
                    key, value = line.split('=', 1)
                    metadata[key] = value
            expected_size = int(metadata['size'])
            expected_sha = metadata['sha256']
            if len(expected_sha) != 64:
                raise ValueError
        except (UnicodeDecodeError, KeyError, ValueError):
            print('Invalid START metadata.')
            self.show_ack(ack_window, parsed['sequence'], False)
            return
        self.started = True
        self.total = parsed['total']
        self.metadata = metadata
        self.last_data = -1
        self.packets.clear()
        print(f'File: {metadata.get("name", "unknown")}')
        print(f'Size: {expected_size:,} bytes')
        print(f'Packets: {self.total:,}')
        print(f'SHA-256: {expected_sha}')
        self.show_ack(ack_window, 0, True)

    def handle_data(self, parsed, ack_window):
        sequence = parsed['sequence']
        if not self.started:
            self.show_ack(ack_window, sequence, False)
            return
        if sequence >= self.total:
            print(f'Invalid sequence #{sequence}.')
            self.show_ack(ack_window, sequence, False)
            return
        expected = self.last_data + 1
        if sequence == expected:
            self.packets[sequence] = parsed['payload']
            self.last_data = sequence
            print(f'DATA #{sequence} | CRC OK | {len(parsed["payload"])} bytes')
            self.show_ack(ack_window, sequence, True)
        elif sequence == self.last_data:
            print(f'DUPLICATE DATA #{sequence} | sending ACK again')
            self.show_ack(ack_window, sequence, True)
        else:
            print(f'OUT OF ORDER: got #{sequence}, expected #{expected}')
            self.show_ack(ack_window, sequence, False)

    def handle_end(self, parsed, ack_window):
        sequence = parsed['sequence']
        complete = (self.started and sequence == self.total and len(self.packets) == self.total and self.last_data == self.total - 1)
        if not complete:
            print('END received but transfer is incomplete.')
            self.show_ack(ack_window, sequence, False)
            return False
        try:
            output = self.write_and_verify()
        except Exception as exc:
            print(f'Final verification failed: {exc}')
            self.show_ack(ack_window, sequence, False)
            return False
        self.show_ack(ack_window, sequence, True)
        print('\n' + '=' * 72)
        print('             TRANSFER SUCCESSFUL')
        print('=' * 72)
        print(f'Output: {output}')
        print(f'SHA256: {sha256_file(output)}')
        print('=' * 72)
        return True

    def write_and_verify(self):
        destination = self.ask_output_directory()
        filename = os.path.basename(self.metadata.get('name', 'received_file.bin'))
        output = os.path.join(destination, filename)
        base, ext = os.path.splitext(output)
        counter = 1
        while os.path.exists(output):
            output = f'{base}_{counter}{ext}'
            counter += 1
        with open(output, 'wb') as file:
            for index in range(self.total):
                if index not in self.packets:
                    raise RuntimeError(f'Missing packet #{index}.')
                file.write(self.packets[index])
        actual = sha256_file(output)
        expected = self.metadata['sha256']
        if actual.lower() != expected.lower():
            try:
                os.remove(output)
            except OSError:
                pass
            raise RuntimeError(f'SHA-256 mismatch. Expected {expected}; got {actual}.')
        return output

    @staticmethod
    def ask_output_directory():
        while True:
            value = input('Output folder (ENTER = current folder): ').strip()
            if not value:
                value = os.getcwd()
            value = os.path.abspath(os.path.expanduser(value))
            if os.path.isdir(value):
                return value
            print('That folder does not exist.')
