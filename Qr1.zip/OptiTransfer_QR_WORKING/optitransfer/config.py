from dataclasses import dataclass

@dataclass(frozen=True)
class Config:
    camera_index: int = 0
    camera_width: int = 1280
    camera_height: int = 720
    qr_size: int = 900
    qr_border: int = 4
    qr_box_size: int = 10
    payload_bytes: int = 700
    qr_error_correction: str = 'M'
    ack_timeout_s: float = 5.0
    max_retries: int = 8
    qr_hold_s: float = 0.60
    camera_poll_ms: int = 40

CONFIG = Config()
