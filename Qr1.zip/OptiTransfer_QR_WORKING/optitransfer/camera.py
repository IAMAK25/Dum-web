import cv2

class Camera:
    def __init__(self, config):
        self.config = config
        self.cap = None

    def open(self):
        self.cap = cv2.VideoCapture(self.config.camera_index, cv2.CAP_DSHOW)
        if not self.cap.isOpened():
            self.cap.release()
            self.cap = cv2.VideoCapture(self.config.camera_index)
        if not self.cap.isOpened():
            raise RuntimeError(f'Could not open camera index {self.config.camera_index}. Check camera permissions or change camera_index in config.py.')
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.config.camera_width)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.config.camera_height)
        try:
            self.cap.set(cv2.CAP_PROP_AUTOFOCUS, 1)
        except Exception:
            pass

    def read(self):
        if self.cap is None:
            raise RuntimeError('Camera is not open.')
        ok, frame = self.cap.read()
        if not ok or frame is None:
            raise RuntimeError('Camera frame capture failed.')
        return frame

    def close(self):
        if self.cap is not None:
            self.cap.release()
            self.cap = None
