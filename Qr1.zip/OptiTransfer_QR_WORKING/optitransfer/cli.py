from .config import CONFIG
from .receiver import Receiver
from .sender import Sender

class CLI:
    def __init__(self):
        self.sender = Sender(CONFIG)
        self.receiver = Receiver(CONFIG)

    @staticmethod
    def banner():
        print('\n' + '=' * 72)
        print('                 OPTITRANSFER')
        print('              OFFLINE QR TRANSFER')
        print('=' * 72)
        print('No Wi-Fi | No Bluetooth | No LAN | No Internet')
        print('QR DATA + QR ACK | Strict Stop-and-Wait')
        print('=' * 72)

    @staticmethod
    def menu():
        print('\n[1] Sender\n[2] Receiver\n[3] Exit\n')
        return input('Choice: ').strip()

    def run(self):
        self.banner()
        while True:
            try:
                choice = self.menu()
                if choice == '1':
                    self.sender_mode()
                elif choice == '2':
                    self.receiver_mode()
                elif choice == '3':
                    print('Exiting.')
                    return
                else:
                    print('Enter 1, 2, or 3.')
            except (KeyboardInterrupt, EOFError):
                print('\nExiting.')
                return

    def sender_mode(self):
        print('\n' + '-' * 72 + '\nSENDER\n' + '-' * 72)
        path = input('File path: ').strip().strip('"')
        if not path:
            print('No file selected.')
            return
        try:
            self.sender.run(path)
        except Exception as exc:
            print(f'\n[ERROR] {exc}')

    def receiver_mode(self):
        print('\n' + '-' * 72 + '\nRECEIVER\n' + '-' * 72)
        try:
            self.receiver.run()
        except Exception as exc:
            print(f'\n[ERROR] {exc}')
