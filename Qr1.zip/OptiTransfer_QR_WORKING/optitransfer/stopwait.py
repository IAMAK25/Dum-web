import time
import cv2
from .protocol import FrameType, unpack_frame

class StopAndWaitSender:
    def __init__(self, config, qr, camera):
        self.config = config
        self.qr = qr
        self.camera = camera
        self.retries = 0

    def display_data_qr(self, window, frame_bytes):
        image = self.qr.encode(frame_bytes)
        cv2.imshow(window, image)
        cv2.waitKey(1)
        time.sleep(self.config.qr_hold_s)

    def wait_for_ack(self, sequence, camera_window):
        deadline = time.monotonic() + self.config.ack_timeout_s
        while time.monotonic() < deadline:
            frame = self.camera.read()
            cv2.imshow(camera_window, self.qr.draw_overlay(frame, 'ACK CAMERA ACTIVE - SEARCHING...'))
            cv2.waitKey(1)
            raw = self.qr.decode(frame)
            if raw is None:
                continue
            parsed = unpack_frame(raw)
            if parsed is None or parsed['sequence'] != sequence:
                continue
            if parsed['type'] == FrameType.ACK:
                return True
            if parsed['type'] == FrameType.NACK:
                return False
        return None

    def send_packet(self, qr_window, camera_window, frame_bytes, sequence, label):
        for attempt in range(1, self.config.max_retries + 2):
            print(f'TX {label} #{sequence} (attempt {attempt})')
            self.display_data_qr(qr_window, frame_bytes)
            # STRICT STOP-AND-WAIT: do not send next packet until this returns.
            result = self.wait_for_ack(sequence, camera_window)
            if result is True:
                print(f'<- ACK #{sequence}')
                return True
            if result is False:
                print(f'<- NACK #{sequence}; retransmitting SAME packet')
            else:
                print(f'ACK #{sequence} timeout; retransmitting SAME packet')
            self.retries += 1
        return False
