import base64
import cv2
import numpy as np
import qrcode

class QRCodec:
    def __init__(self, config):
        self.config = config
        correction = {
            'L': qrcode.constants.ERROR_CORRECT_L,
            'M': qrcode.constants.ERROR_CORRECT_M,
            'Q': qrcode.constants.ERROR_CORRECT_Q,
            'H': qrcode.constants.ERROR_CORRECT_H,
        }[config.qr_error_correction]
        self.error_correction = correction
        self.detector = cv2.QRCodeDetector()

    def encode(self, raw):
        # Binary-safe transport: binary -> Base64 ASCII -> QR.
        text = base64.b64encode(bytes(raw)).decode('ascii')
        qr = qrcode.QRCode(version=None, error_correction=self.error_correction, box_size=self.config.qr_box_size, border=self.config.qr_border)
        qr.add_data(text, optimize=0)
        qr.make(fit=True)
        image = np.asarray(qr.make_image(fill_color='black', back_color='white').convert('L'), dtype=np.uint8)
        return cv2.resize(image, (self.config.qr_size, self.config.qr_size), interpolation=cv2.INTER_NEAREST)

    @staticmethod
    def _variants(frame):
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        variants = [gray]
        variants.append(cv2.resize(gray, None, fx=1.5, fy=1.5, interpolation=cv2.INTER_CUBIC))
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        variants.append(clahe.apply(gray))
        blur = cv2.GaussianBlur(gray, (0, 0), 1.2)
        variants.append(cv2.addWeighted(gray, 1.6, blur, -0.6, 0))
        _, otsu = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        variants.append(otsu)
        variants.append(cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 31, 5))
        return variants

    def decode(self, frame):
        for image in self._variants(frame):
            try:
                text, points, _ = self.detector.detectAndDecode(image)
            except cv2.error:
                text = ''
            if not text:
                continue
            try:
                raw = base64.b64decode(text.encode('ascii'), validate=True)
            except (UnicodeEncodeError, ValueError, base64.binascii.Error):
                continue
            return raw
        return None

    @staticmethod
    def draw_overlay(frame, status, color=(0, 220, 255)):
        out = frame.copy()
        cv2.rectangle(out, (0, 0), (out.shape[1], 62), (0, 0, 0), -1)
        cv2.putText(out, status, (18, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.75, color, 2, cv2.LINE_AA)
        return out
