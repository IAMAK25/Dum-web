import struct
import zlib
from enum import IntEnum

MAGIC = b'OPQR'
VERSION = 1
HEADER = struct.Struct('>4sBBBBII')
U32 = struct.Struct('>I')

class FrameType(IntEnum):
    START = 1
    DATA = 2
    ACK = 3
    NACK = 4
    END = 5

def pack_frame(frame_type, sequence, total, payload=b'', flags=0):
    payload = bytes(payload)
    header = HEADER.pack(MAGIC, VERSION, int(frame_type), flags & 0xFF, 0, int(sequence), int(total))
    body = header + U32.pack(len(payload)) + payload
    return body + U32.pack(zlib.crc32(body) & 0xFFFFFFFF)

def unpack_frame(raw):
    if raw is None or len(raw) < HEADER.size + 8:
        return None
    try:
        magic, version, frame_type, flags, _reserved, sequence, total = HEADER.unpack(raw[:HEADER.size])
        payload_length = U32.unpack(raw[HEADER.size:HEADER.size+4])[0]
    except struct.error:
        return None
    if magic != MAGIC or version != VERSION:
        return None
    start = HEADER.size + 4
    end = start + payload_length
    if end + 4 != len(raw):
        return None
    body = raw[:end]
    received = U32.unpack(raw[end:end+4])[0]
    if (zlib.crc32(body) & 0xFFFFFFFF) != received:
        return None
    try:
        kind = FrameType(frame_type)
    except ValueError:
        return None
    return {'type': kind, 'flags': flags, 'sequence': sequence, 'total': total, 'payload': raw[start:end]}
