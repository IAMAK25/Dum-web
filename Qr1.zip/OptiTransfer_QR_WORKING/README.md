# OptiTransfer QR - Working CMD Project

This version fixes the previous receiver problem.

## Main fix

Arbitrary binary packets are NOT inserted directly into QR text.

The transport is:

binary packet -> Base64 ASCII -> QR -> camera -> Base64 -> binary packet

This makes ZIP/PDF/JPG/EXE/etc. safe for QR text decoding.

## Receiver fix

The receiver opens the live camera preview immediately and continuously shows:

CAMERA ACTIVE - SEARCHING FOR QR...

When a valid packet is decoded it prints:

QR DETECTED: DATA #N
DATA #N | CRC OK
-> ACK #N

## Strict stop-and-wait

DATA N is displayed -> receiver sends ACK N -> sender reads ACK N -> only then DATA N+1 is displayed.

If ACK is lost, the sender retransmits the same packet. The receiver recognizes the duplicate and sends the ACK again without storing the payload twice.

## Install

```cmd
python -m pip install -r requirements.txt
```

## Run on both laptops

```cmd
python main.py
```

Laptop A: Sender
Laptop B: Receiver

Point Laptop B camera at Laptop A QR window. Then point Laptop A camera at Laptop B ACK window.

## Camera permissions

On Windows allow Camera access and allow desktop apps to access the camera. Close Teams/Zoom/other apps using the webcam.

If the wrong camera is selected, change `camera_index = 0` in `optitransfer/config.py` to `1`.

## Reliability tips

Maximize the QR window, use high screen brightness, avoid glare, keep the camera perpendicular to the screen, and let autofocus settle.

## Persistence

The application creates no packet/chunk files or application transfer log. The receiver writes only the final reconstructed file. This cannot guarantee zero OS-level traces from Windows, antivirus, drivers, pagefile, crash dumps, etc.
