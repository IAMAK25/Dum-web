import time
from .protocol import FrameType

class StopAndWaitARQ:
    def __init__(self,cfg): self.cfg,self.retries=cfg,0
    def send_reliably(self, frame, sequence, display, receive_control):
        for attempt in range(self.cfg.max_retries+1):
            display(frame)
            deadline=time.monotonic()+self.cfg.ack_timeout_s
            while time.monotonic()<deadline:
                control=receive_control(max(0,deadline-time.monotonic()))
                if not control or control["sequence"]!=sequence: continue
                if control["type"]==FrameType.ACK: return True
                if control["type"]==FrameType.NACK:
                    self.retries+=1; break
            else:
                if attempt < self.cfg.max_retries: self.retries+=1
        return False
