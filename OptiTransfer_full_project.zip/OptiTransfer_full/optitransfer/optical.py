import cv2
import numpy as np

class OpticalCodec:
    def __init__(self, cfg):
        self.cfg = cfg
        self.capacity_bytes = (cfg.cols * cfg.rows) // 8

    def encode(self, payload):
        if len(payload) > self.capacity_bytes:
            raise ValueError(f"Frame too large: {len(payload)} > {self.capacity_bytes} bytes")
        bits = np.unpackbits(np.frombuffer(bytes(payload).ljust(self.capacity_bytes, b"\0"), dtype=np.uint8))
        s = self.cfg.board_size
        board = np.full((s, s), 255, np.uint8)
        b = max(5, s // 90)
        board[:b] = board[-b:] = 0
        board[:, :b] = board[:, -b:] = 0
        fs, m = s // 8, s // 35
        for x, y in [(m,m),(s-m-fs,m),(m,s-m-fs),(s-m-fs,s-m-fs)]:
            board[y:y+fs, x:x+fs] = 0
            inner, off = fs//2, fs//4
            board[y+off:y+off+inner, x+off:x+off+inner] = 255
        left, top, right, bottom = fs+2*m, fs+2*m, s-fs-2*m, s-fs-2*m
        cw, ch = (right-left)/self.cfg.cols, (bottom-top)/self.cfg.rows
        for i, bit in enumerate(bits):
            r, c = divmod(i, self.cfg.cols)
            x0, x1 = int(left+c*cw), int(left+(c+1)*cw)
            y0, y1 = int(top+r*ch), int(top+(r+1)*ch)
            board[y0:y1, x0:x1] = 255 if bit else 0
        return board

    @staticmethod
    def order_corners(points):
        out = np.zeros((4,2), np.float32)
        sums, diffs = points.sum(axis=1), np.diff(points, axis=1).reshape(-1)
        out[0], out[2] = points[np.argmin(sums)], points[np.argmax(sums)]
        out[1], out[3] = points[np.argmin(diffs)], points[np.argmax(diffs)]
        return out

    def locate_board(self, frame):
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        blur = cv2.GaussianBlur(gray, (5,5), 0)
        _, th = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
        contours, _ = cv2.findContours(th, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        h, w = gray.shape
        candidates = []
        for c in contours:
            area = cv2.contourArea(c)
            if not h*w*self.cfg.min_board_fraction <= area <= h*w*self.cfg.max_board_fraction:
                continue
            peri = cv2.arcLength(c, True)
            approx = cv2.approxPolyDP(c, .03*peri, True)
            if len(approx) != 4:
                continue
            x,y,cw,ch = cv2.boundingRect(approx)
            if cw < .25*w or ch < .25*h:
                continue
            ratio = cw/max(ch,1)
            if .55 <= ratio <= 1.8:
                candidates.append((area, approx.reshape(4,2).astype(np.float32)))
        return self.order_corners(max(candidates, key=lambda z:z[0])[1]) if candidates else None

    def rectify(self, frame, corners):
        s = self.cfg.board_size
        dst = np.array([[0,0],[s-1,0],[s-1,s-1],[0,s-1]], np.float32)
        mat = cv2.getPerspectiveTransform(corners.astype(np.float32), dst)
        return cv2.warpPerspective(frame, mat, (s,s))

    def decode(self, board):
        gray = cv2.cvtColor(board, cv2.COLOR_BGR2GRAY) if board.ndim == 3 else board
        s, fs, m = self.cfg.board_size, self.cfg.board_size//8, self.cfg.board_size//35
        left, top, right, bottom = fs+2*m, fs+2*m, s-fs-2*m, s-fs-2*m
        cw, ch = (right-left)/self.cfg.cols, (bottom-top)/self.cfg.rows
        bits = []
        for r in range(self.cfg.rows):
            for c in range(self.cfg.cols):
                cx, cy = int(left+(c+.5)*cw), int(top+(r+.5)*ch)
                rad = max(1, int(min(cw,ch)*.18))
                roi = gray[cy-rad:cy+rad+1, cx-rad:cx+rad+1]
                if roi.size == 0: return None
                bits.append(1 if float(np.mean(roi)) >= 128 else 0)
        return np.packbits(np.asarray(bits, np.uint8)).tobytes()
