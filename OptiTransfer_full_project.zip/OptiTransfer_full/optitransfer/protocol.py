import struct, zlib
from enum import IntEnum

MAGIC = b"OPT5"
VERSION = 1
HEADER = struct.Struct(">4sBBBBII")
U32 = struct.Struct(">I")

class FrameType(IntEnum):
    START = 1
    DATA = 2
    ACK = 3
    NACK = 4
    END = 5
    FINAL_ACK = 6

def pack_frame(frame_type, sequence, total, payload=b"", flags=0):
    payload = bytes(payload)
    header = HEADER.pack(MAGIC, VERSION, int(frame_type), flags & 255, 0, int(sequence), int(total))
    body = header + U32.pack(len(payload)) + payload
    return body + U32.pack(zlib.crc32(body) & 0xffffffff)

def unpack_frame(raw):
    if raw is None or len(raw) < HEADER.size + 8:
        return None
    try:
        magic, version, kind, flags, _, seq, total = HEADER.unpack(raw[:HEADER.size])
        length = U32.unpack(raw[HEADER.size:HEADER.size+4])[0]
    except struct.error:
        return None
    if magic != MAGIC or version != VERSION:
        return None
    start = HEADER.size + 4
    end = start + length
    if end + 4 > len(raw):
        return None
    body = raw[:end]
    if U32.unpack(raw[end:end+4])[0] != (zlib.crc32(body) & 0xffffffff):
        return None
    try:
        kind = FrameType(kind)
    except ValueError:
        return None
    return {"type": kind, "flags": flags, "sequence": seq, "total": total, "payload": raw[start:end]}
