from dataclasses import dataclass

@dataclass(frozen=True)
class Config:
    board_size: int = 900
    cols: int = 40
    rows: int = 30
    camera_index: int = 0
    camera_width: int = 1280
    camera_height: int = 720
    frame_hold_s: float = 0.25
    stable_frames: int = 2
    ack_timeout_s: float = 2.5
    max_retries: int = 8
    min_board_fraction: float = 0.12
    max_board_fraction: float = 0.98
    io_chunk: int = 1024 * 1024

CONFIG = Config()
