import os, time, tkinter as tk, cv2
from tkinter import filedialog
from .optical import OpticalCodec
from .protocol import FrameType, pack_frame
from .integrity import sha256_file
from .transport import StopAndWaitARQ

class Sender:
    def __init__(self,cfg): self.cfg,self.codec,self.arq=cfg,OpticalCodec(cfg),StopAndWaitARQ(cfg)
    def choose_file(self):
        r=tk.Tk(); r.withdraw(); p=filedialog.askopenfilename(title="Select file to transfer"); r.destroy(); return p
    def show(self, board):
        cv2.imshow("OptiTransfer - Sender",board); cv2.waitKey(1); time.sleep(self.cfg.frame_hold_s)
    def run(self,path=None):
        path=path or self.choose_file()
        if not path: return
        if not os.path.isfile(path): raise FileNotFoundError(path)
        size=os.path.getsize(path); digest=sha256_file(path)
        cap=max(1,self.codec.capacity_bytes-64); total=(size+cap-1)//cap
        meta=f"name={os.path.basename(path)}\nsize={size}\nsha256={digest}\n".encode()
        print(f"File: {path}\nSize: {size:,}\nSHA-256: {digest}\nPackets: {total}")
        cv2.namedWindow("OptiTransfer - Sender",cv2.WINDOW_NORMAL)
        self.show(self.codec.encode(pack_frame(FrameType.START,0,total,meta)))
        start=time.monotonic(); sent=0
        with open(path,"rb") as f:
            while True:
                data=f.read(cap)
                if not data: break
                self.show(self.codec.encode(pack_frame(FrameType.DATA,sent,total,data)))
                sent+=1
                speed=(sent*cap)/max(time.monotonic()-start,.001)/1024
                print(f"\rPacket {sent}/{total} | {sent*100/total:6.2f}% | {speed:.2f} KB/s",end="",flush=True)
        self.show(self.codec.encode(pack_frame(FrameType.END,total,total)))
        print(f"\nDisplay pass complete. ARQ retries: {self.arq.retries}")
        print("For full physical ACK operation, connect the sender camera decoder to StopAndWaitARQ.receive_control().")
        cv2.waitKey(0); cv2.destroyAllWindows()
