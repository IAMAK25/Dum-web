import tkinter as tk
from tkinter import filedialog, messagebox

class App:
    def __init__(self,sender,receiver):
        self.sender,self.receiver=sender,receiver
        self.root=tk.Tk(); self.root.title("OptiTransfer"); self.root.geometry("520x420"); self.root.resizable(False,False)
        tk.Label(self.root,text="OPTITRANSFER",font=("Segoe UI",24,"bold")).pack(pady=(35,5))
        tk.Label(self.root,text="Offline Bidirectional Optical File Transfer",font=("Segoe UI",11)).pack(pady=(0,25))
        self.btn("SEND FILE",self.send); self.btn("RECEIVE FILE",self.receive); self.btn("EXIT",self.root.destroy)
        tk.Label(self.root,text="No Wi-Fi • No Bluetooth • No LAN • No Internet\nDisplay ↔ Camera optical communication",font=("Segoe UI",9)).pack(pady=25)
    def btn(self,text,cmd): tk.Button(self.root,text=text,width=28,height=2,command=cmd).pack(pady=8)
    def send(self):
        p=filedialog.askopenfilename(title="Select file to transfer")
        if not p:return
        try:self.sender.run(p)
        except Exception as e:messagebox.showerror("Sender Error",str(e))
    def receive(self):
        try:self.receiver.run()
        except Exception as e:messagebox.showerror("Receiver Error",str(e))
    def run(self):self.root.mainloop()
