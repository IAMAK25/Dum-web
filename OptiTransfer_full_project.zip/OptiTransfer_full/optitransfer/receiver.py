import os, cv2
from .camera import Camera
from .optical import OpticalCodec
from .protocol import FrameType, unpack_frame
from .integrity import sha256_file

class Receiver:
    def __init__(self,cfg): self.cfg,self.codec,self.camera=cfg,OpticalCodec(cfg),Camera(cfg)
    def run(self,output_dir="received_files"):
        os.makedirs(output_dir,exist_ok=True); self.camera.open()
        packets={}; total=None; meta={}
        cv2.namedWindow("OptiTransfer - Receiver",cv2.WINDOW_NORMAL)
        try:
            while True:
                frame=self.camera.read(); preview=frame.copy(); corners=self.codec.locate_board(frame)
                if corners is not None:
                    cv2.polylines(preview,[corners.astype("int32")],True,(0,255,0),2)
                    parsed=unpack_frame(self.codec.decode(self.codec.rectify(frame,corners)))
                    if parsed:
                        kind,seq=parsed["type"],parsed["sequence"]
                        cv2.putText(preview,f"{kind.name} #{seq}",(20,40),cv2.FONT_HERSHEY_SIMPLEX,.8,(0,255,0),2)
                        if kind==FrameType.START:
                            meta=dict(x.split("=",1) for x in parsed["payload"].decode(errors="strict").splitlines() if "=" in x); total=parsed["total"]
                            print(f"START: {meta.get('name','unknown')} | {meta.get('size','?')} bytes")
                        elif kind==FrameType.DATA:
                            total=parsed["total"]
                            if seq not in packets: packets[seq]=parsed["payload"]; print(f"\rReceived {len(packets)}/{total}",end="",flush=True)
                        elif kind==FrameType.END:
                            total=parsed["total"]
                            if total is not None and len(packets)==total: break
                cv2.imshow("OptiTransfer - Receiver",preview); key=cv2.waitKey(1)&255
                if key in (27,ord("q")): return
        finally:
            self.camera.close(); cv2.destroyAllWindows()
        if total is None: raise RuntimeError("No valid transfer frames received")
        missing=[i for i in range(total) if i not in packets]
        if missing: raise RuntimeError(f"Missing packets: {missing[:10]}")
        name=os.path.basename(meta.get("name","received_file.bin")); out=os.path.join(output_dir,name)
        base,ext=os.path.splitext(out); n=1
        while os.path.exists(out): out=f"{base}_{n}{ext}"; n+=1
        with open(out,"wb") as f:
            for i in range(total): f.write(packets[i])
        actual=sha256_file(out); expected=meta.get("sha256")
        print(f"\nOutput: {out}\nSHA-256: {actual}")
        if expected and actual!=expected: raise RuntimeError(f"SHA-256 mismatch: expected {expected}, got {actual}")
        print("SHA-256: VERIFIED\nTRANSFER SUCCESSFUL")
