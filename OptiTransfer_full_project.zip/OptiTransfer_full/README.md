# OptiTransfer

Offline optical file transfer between two laptops. The intended transport is display -> camera, with optical control frames in the reverse direction. No Wi-Fi, Bluetooth, LAN, Internet, sockets, USB, or cloud transport is used.

## Install

Python 3.10+ recommended.

```bash
python -m venv .venv
# Windows
.venv\\Scripts\\activate
# macOS/Linux
source .venv/bin/activate
pip install -r requirements.txt
python main.py
```

Run the same program on both laptops. Choose SEND FILE on A and RECEIVE FILE on B.

## Components

- custom optical board, not QR
- black/white payload grid
- finder markers and perspective correction
- framed protocol with START/DATA/ACK/NACK/END/FINAL_ACK
- CRC32 per frame
- SHA-256 whole-file verification
- streaming file I/O
- camera preview and automatic board detection
- stop-and-wait ARQ state-machine abstraction
- Tkinter GUI

## Reality check

The camera/display channel is much slower and less reliable than a network. Start with tiny files and calibrate the optical density. The project is structured so physical ACK capture, calibration, adaptive rate, and stronger synchronization can be tuned for the actual laptops.
