# OptiTransfer QR CMD

QR-only offline optical transfer. Both laptops run the same `main.py`. Sender displays one QR, waits for the matching ACK QR, then sends the next packet. Receiver uses OpenCV `QRCodeDetector` only; the previous custom optical-grid decoder is removed.

Install: `pip install -r requirements.txt`
Run: `python main.py`

10–20 MB files are supported by splitting them into many QR packets. The conservative payload is 700 bytes/QR for webcam reliability. Throughput depends strongly on camera/screen conditions.

Each packet has magic/version/type/sequence/total/payload length/payload/CRC32. Final output is verified with SHA-256. The app intentionally creates no transfer logs or chunk files; it writes only the final receiver file. OS-level traces cannot be guaranteed to be zero.

Protocol: START -> ACK -> DATA #0 -> ACK #0 -> DATA #1 -> ACK #1 -> ... -> END -> ACK. Duplicate DATA causes ACK retransmission without duplicate storage.
