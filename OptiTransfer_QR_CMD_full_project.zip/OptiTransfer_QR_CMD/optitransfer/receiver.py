import os,time,cv2
from .camera import Camera
from .integrity import sha256_file
from .protocol import FrameType,pack_frame,unpack_frame
from .qr import QRCodec
class Receiver:
 def __init__(self,c):self.c=c;self.qr=QRCodec(c);self.cam=Camera(c);self.started=False;self.total=None;self.meta={};self.last=-1;self.packets={}
 def show_ack(self,w,seq,ok=True):
  cv2.imshow(w,self.qr.encode(pack_frame(FrameType.ACK if ok else FrameType.NACK,seq,self.total or 0)));cv2.waitKey(1);print(f" -> {'ACK' if ok else 'NACK'} #{seq}");time.sleep(self.c.ack_hold_s)
 def run(self):
  print("\nOPTITRANSFER QR RECEIVER\nPoint camera at sender screen. Waiting for START...")
  self.cam.open(); cw="OptiTransfer - CAMERA"; aw="OptiTransfer - ACK QR"; cv2.namedWindow(cw,cv2.WINDOW_NORMAL);cv2.namedWindow(aw,cv2.WINDOW_NORMAL)
  try:
   while True:
    frame=self.cam.read(); raw=self.qr.decode(frame); p=unpack_frame(raw) if raw else None
    if p:
     frame=self.qr.status(frame,f"{p['type'].name} #{p['sequence']}")
     if p["type"]==FrameType.START:self.start(p,aw)
     elif p["type"]==FrameType.DATA:self.data(p,aw)
     elif p["type"]==FrameType.END and self.end(p,aw):break
    cv2.imshow(cw,frame)
    if cv2.waitKey(self.c.camera_poll_ms)&255 in (27,ord('q'),ord('Q')):return
  finally:self.cam.close();cv2.destroyAllWindows()
  input("Press ENTER...")
 def start(self,p,w):
  if p["sequence"]!=0:return self.show_ack(w,p["sequence"],False)
  try:
   m={k:v for line in p["payload"].decode().splitlines() if "=" in line for k,v in [line.split("=",1)]}; int(m["size"]); assert len(m["sha256"])==64
  except Exception:self.show_ack(w,0,False);return
  self.meta=m;self.total=p["total"];self.started=True;self.last=-1;self.packets.clear();print(f"\nSTART: {m.get('name')} | {m.get('size')} bytes | {self.total} packets");self.show_ack(w,0,True)
 def data(self,p,w):
  s=p["sequence"]; expected=self.last+1
  if not self.started or s>=self.total:return self.show_ack(w,s,False)
  if s==expected:
   self.packets[s]=p["payload"];self.last=s;print(f"DATA #{s} | CRC OK | {len(p['payload'])} bytes");self.show_ack(w,s,True)
  elif s==self.last:
   print(f"Duplicate #{s}; re-ACK");self.show_ack(w,s,True)
  else:self.show_ack(w,s,False)
 def end(self,p,w):
  s=p["sequence"]; complete=self.started and s==self.total and len(self.packets)==self.total and self.last==self.total-1
  if not complete:self.show_ack(w,s,False);return False
  out=self.write_verify();self.show_ack(w,s,True);print(f"\nTRANSFER SUCCESSFUL\nOutput: {out}\nSHA-256: {sha256_file(out)}");return True
 def write_verify(self):
  d=input("Output folder (ENTER=current): ").strip() or os.getcwd();d=os.path.abspath(os.path.expanduser(d));
  if not os.path.isdir(d):raise RuntimeError("Output folder does not exist")
  name=os.path.basename(self.meta.get("name","received_file.bin"));out=os.path.join(d,name);base,ext=os.path.splitext(out);i=1
  while os.path.exists(out):out=f"{base}_{i}{ext}";i+=1
  with open(out,"wb") as f:
   for n in range(self.total):f.write(self.packets[n])
  actual=sha256_file(out)
  if actual.lower()!=self.meta["sha256"].lower():
   try:os.remove(out)
   except OSError:pass
   raise RuntimeError(f"SHA-256 mismatch: {actual}")
  return out
