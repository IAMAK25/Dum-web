import hashlib
def sha256_file(path,chunk_size=1024*1024):
 d=hashlib.sha256()
 with open(path,"rb") as f:
  while c:=f.read(chunk_size): d.update(c)
 return d.hexdigest()
