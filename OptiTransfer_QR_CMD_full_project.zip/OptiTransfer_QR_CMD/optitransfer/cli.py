from .config import CONFIG
from .sender import Sender
from .receiver import Receiver
class CLI:
 def __init__(self):self.s=Sender(CONFIG);self.r=Receiver(CONFIG)
 def run(self):
  print("="*68);print("OPTITRANSFER - OFFLINE QR FILE TRANSFER");print("No Wi-Fi | No Bluetooth | No LAN | No Internet");print("="*68)
  while True:
   print("\n[1] Sender\n[2] Receiver\n[3] Exit");c=input("Choice: ").strip()
   if c=="1":
    try:self.s.run(input("File path: ").strip().strip('"'))
    except Exception as e:print(f"[ERROR] {e}")
   elif c=="2":
    try:self.r.run()
    except Exception as e:print(f"[ERROR] {e}")
   elif c=="3":return
   else:print("Invalid choice")
