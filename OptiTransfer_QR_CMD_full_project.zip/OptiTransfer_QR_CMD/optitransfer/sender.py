import os,time,cv2
from .camera import Camera
from .integrity import sha256_file
from .protocol import FrameType,pack_frame
from .qr import QRCodec
from .stopwait import StopWait
class Sender:
 def __init__(self,c): self.c=c;self.qr=QRCodec(c);self.cam=Camera(c);self.sw=StopWait(c,self.qr,self.cam)
 def run(self,path):
  path=os.path.abspath(os.path.expanduser(path));
  if not os.path.isfile(path):raise FileNotFoundError(path)
  size=os.path.getsize(path); digest=sha256_file(path); chunk=self.c.payload_bytes; total=max(1,(size+chunk-1)//chunk)
  meta=f"name={os.path.basename(path)}\nsize={size}\nsha256={digest}\n".encode(); w="OptiTransfer - SEND QR"; cv2.namedWindow(w,cv2.WINDOW_NORMAL); self.cam.open()
  try:
   print("\n"+"="*68);print("OPTITRANSFER QR SENDER - STRICT STOP-AND-WAIT");print(f"File: {path}\nSize: {size:,} bytes\nPayload/QR: {chunk} bytes\nPackets: {total:,}\nSHA-256: {digest}");print("="*68);input("Press ENTER when receiver is ready...")
   if not self.sw.send(w,pack_frame(FrameType.START,0,total,meta),0,"START"):raise RuntimeError("START handshake failed")
   start=time.monotonic(); sent=0; nbytes=0
   with open(path,"rb") as f:
    while data:=f.read(chunk):
     if not self.sw.send(w,pack_frame(FrameType.DATA,sent,total,data),sent,"DATA"):raise RuntimeError(f"DATA #{sent} failed")
     sent+=1;nbytes+=len(data);print(f" Progress: {sent}/{total} ({sent*100/total:6.2f}%)")
   if not self.sw.send(w,pack_frame(FrameType.END,total,total),total,"END"):raise RuntimeError("END not acknowledged")
   print(f"\nTRANSFER COMPLETE | {nbytes:,} bytes | {time.monotonic()-start:.1f}s | retries={self.sw.retries}");input("Press ENTER...")
  finally:self.cam.close();cv2.destroyAllWindows()
