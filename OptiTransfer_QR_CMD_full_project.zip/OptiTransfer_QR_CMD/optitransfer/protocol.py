import struct,zlib
from enum import IntEnum
MAGIC=b"OPQR"; VERSION=1; HEADER=struct.Struct(">4sBBBBII"); U32=struct.Struct(">I")
class FrameType(IntEnum): START=1; DATA=2; ACK=3; NACK=4; END=5
def pack_frame(ft,seq,total,payload=b"",flags=0):
    h=HEADER.pack(MAGIC,VERSION,int(ft),flags&255,0,int(seq),int(total)); body=h+U32.pack(len(payload))+bytes(payload); return body+U32.pack(zlib.crc32(body)&0xffffffff)
def unpack_frame(raw):
    if raw is None or len(raw)<HEADER.size+8:return None
    try: magic,ver,ft,flags,res,seq,total=HEADER.unpack(raw[:HEADER.size]); n=U32.unpack(raw[HEADER.size:HEADER.size+4])[0]
    except struct.error:return None
    if magic!=MAGIC or ver!=VERSION:return None
    a=HEADER.size+4; b=a+n
    if b+4>len(raw):return None
    body=raw[:b]
    if U32.unpack(raw[b:b+4])[0] != zlib.crc32(body)&0xffffffff:return None
    try: kind=FrameType(ft)
    except ValueError:return None
    return {"type":kind,"sequence":seq,"total":total,"payload":raw[a:b],"flags":flags}
