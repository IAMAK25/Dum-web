import time,cv2
from .protocol import FrameType,unpack_frame
class StopWait:
 def __init__(self,c,qr,cam):self.c=c;self.qr=qr;self.cam=cam;self.retries=0
 def show(self,w,raw,hold):
  cv2.imshow(w,self.qr.encode(raw));cv2.waitKey(1);time.sleep(hold)
 def wait_ack(self,seq):
  end=time.monotonic()+self.c.ack_timeout_s
  while time.monotonic()<end:
   raw=self.qr.decode(self.cam.read())
   p=unpack_frame(raw) if raw else None
   if p and p["sequence"]==seq and p["type"] in (FrameType.ACK,FrameType.NACK):return p["type"]==FrameType.ACK
   cv2.waitKey(self.c.camera_poll_ms)
  return None
 def send(self,w,raw,seq,label):
  for attempt in range(1,self.c.max_retries+2):
   print(f"\n TX {label} #{seq} (attempt {attempt})"); self.show(w,raw,self.c.data_hold_s); r=self.wait_ack(seq)
   if r is True: print(f" <- ACK #{seq}"); return True
   print(f" !! {'NACK' if r is False else 'ACK timeout'} #{seq}; retransmitting same packet"); self.retries+=1
  return False
