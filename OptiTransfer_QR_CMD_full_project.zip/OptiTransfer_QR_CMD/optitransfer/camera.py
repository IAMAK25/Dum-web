import cv2
class Camera:
 def __init__(self,c): self.c=c; self.cap=None
 def open(self):
  self.cap=cv2.VideoCapture(self.c.camera_index); self.cap.set(cv2.CAP_PROP_FRAME_WIDTH,self.c.camera_width); self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT,self.c.camera_height)
  if not self.cap.isOpened(): raise RuntimeError("Unable to open camera. Check permission/camera_index.")
 def read(self):
  ok,f=self.cap.read()
  if not ok or f is None: raise RuntimeError("Camera frame capture failed.")
  return f
 def close(self):
  if self.cap is not None:self.cap.release();self.cap=None
